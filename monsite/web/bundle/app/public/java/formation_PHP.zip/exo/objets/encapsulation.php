<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * le terme "encapsulation" désigne le regroupement des variable et des fonction au sein 
         * d'une seule et meme entité : une classe.
         * par defaut toute les propriétés et méthode d'une classe sont de type public
         * 
         * vous pouvez également définir des propriété et méthode private 
         * elle ne seront utilisables et modifiable que par la classe elle-meme
         * 
         * vous pouvez aussi définir des propriétés et méthode potected elle seront 
         * utilisable et modifiables par la classe elle meme et par ses classe dérivées
         * 
         */
        ?>
    </body>
</html>
