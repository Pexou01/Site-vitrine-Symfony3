<?php
/**
 * exemple de controleur
 */
$tri = $_GET['tri'];
include_once ("/modele/exemple_de_modele");

//Modéle
// Demande de données au modéle
$donnees = trier($tri);

// CONTROLLEUR 
// MISE EN GRAS DE LA COLONE TRIEE
foreach ($donnees as &$ligne){
    $ligne[$tri] = "<b><i>".$ligne[$tri]."</i></b>";
}

// vue
//AFFICHAGE DES RESULTAT
include_once ('/vue/exemple_de_vue.php');
