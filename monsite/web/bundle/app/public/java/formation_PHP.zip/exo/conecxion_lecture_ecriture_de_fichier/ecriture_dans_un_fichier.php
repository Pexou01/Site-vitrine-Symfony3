<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * pour ecrire des données dans un fichier on utilise 
         * fputs[$handle,texte);
         * 
         * ou
         * $handle est le handle du fichier retourné par la fonctoin fopen()
         * texte est le texte à écrire dans les fichier 
         * 
         * si on ouvre le fichier avec a+ alort les données seront mi a la fin
         * si on ouvre le fichier avec r+ alort les données seront mi a la place choisi avec 
         * fseek($handle,possition);
         * 
         * ou:
         * position est la position d'écriture en caractére a partir de 0
         */
        $handle= fopen("doto.txt","a+");
        $visite="";
         $ecriture = fputs($handle,"coucou toi sa va ?",40);
         if($ecriture ){
             $ecriture = fputs($handle,"Oui est toi ?",40);
             $visite ++;
             echo "le fichier à etais modifier"."<br>";
              echo "$visite";
         }
         
        ?>
    </body>
</html>
