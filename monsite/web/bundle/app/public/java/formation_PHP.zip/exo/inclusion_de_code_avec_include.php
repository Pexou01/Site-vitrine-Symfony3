<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
 include "initialisation.php";
 echo "\$a = ".$a."<br>";
 echo "\$b = ".$b;
        ?>
    </body>
</html>
