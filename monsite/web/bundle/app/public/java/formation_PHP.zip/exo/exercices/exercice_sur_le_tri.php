<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
       
        $tab = array("Jean", "Pierre", "Frédéric", "Marc", "Patric", "Eva");
        /**
         * tri par ordre alaphabétique du tableau
         */
        sort($tab, SORT_STRING);
        foreach ($tab as $element)
            echo $element."<br>";
        
        ?>
    </body>
</html>
