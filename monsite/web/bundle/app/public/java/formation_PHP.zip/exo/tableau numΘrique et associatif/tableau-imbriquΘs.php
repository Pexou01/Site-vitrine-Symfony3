<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * exemple de tableau numeroté imbriqué
         */  
         $tableau = array(
             array(1, 2, 3, 4, 5, 6),
             array("a", "b", "c", "d", "e", "f"),
             array("ici", "un", "peu", "de", "texte")
         );
         
         /**
          * exemple de tableau associatif groupé
          */
         
         $tableau1 = array(
             array("terme"=>"pomme", "définition"=>"fruit"),
             array("terme"=>"poire", "définition"=>"fruit"),
             array("terme"=>"cerise", "définition"=>"fruit")
         );
         
         /**
          * exemple de tableau non simétrique
          */
         
         $tableau2 = array("Romain" => array("un"=>"I", "deux"=>"II", "trois"=>"III", "quatre"=>"IV"),
                           "Arabe" => array("un"=>"1", "deux"=>"2", "trois"=>"3", "quatre"=>"4"));
                    
        ?>
    </body>
</html>
