
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // ici grace a la super global $_post son stoker dans des variable et apres afficher ave l'echo qui suis
       //  htmlspecialchars permet de protege les donne que le client a tapé
        $prenom = htmlspecialchars($_POST["prenom"]);
        $nom = htmlspecialchars($_POST["nom"]);
        $motdepass = htmlspecialchars($_POST["mdp"]);
        $age = htmlspecialchars($_POST["age"]);
        $obs = htmlspecialchars($_POST["observations"]);
        
        echo "<b>Donnée recues :</b><br><br>";
        echo "Prenom : $prenom<br>";
        echo "nom : $nom<br>";
        echo "Mot de passe : $motdepass<br>";
        echo "age : $age<br>";
        echo "observations : $obs<br>";
        
        ?>
    </body>
</html>
