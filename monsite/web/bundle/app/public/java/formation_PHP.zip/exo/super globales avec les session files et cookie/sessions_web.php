<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form name="form" method="post" action="">
            
        </form>
        
        <?php
        /**
         * pour lire ou autre les variable de session on utilise la fonction session_start()
         * ELLE DOIT ETRE APPELER AVANT LE DOCTYPE!
         * 
         * pour mémorisé une donnée dans une variable de session, utilisez une instruction du type suivant:
         * $_SESSOIN["nonVariable"] = valeur;
         * 
         * Pour lire le contenu d'une variable de session, utilisez la superglobale $_SESSION[] en 
         * précisant le nom de la variable entre les crochet et entre guillemets.
         * echo $_SESSION["nomDeVariable"]; 
         */
        ?>
    </body>
</html>
