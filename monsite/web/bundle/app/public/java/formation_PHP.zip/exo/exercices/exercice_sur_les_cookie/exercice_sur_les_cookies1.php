 <?php
 session_start();
 ?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $prenom = htmlspecialchars($_POST["prenom"]);
        $nom = htmlspecialchars($_POST["nom"]);
        setcookie("prenom", $prenom, time()+3600, "", "", FALSE, TRUE);
        setcookie("nom", $nom, time()+3600, "", "", FALSE, TRUE);
        echo "Le cookie de se formulaire est enregistré";
        echo "<a href=\"exercice_sur_les_cookies2.php\">Cliquer sur se lien pour verifier.</a>";
        ?>
    </body>
</html>
