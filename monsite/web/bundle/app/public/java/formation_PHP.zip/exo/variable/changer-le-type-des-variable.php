<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <p>Ce text et fait par le client</p><br>
        <?php
        /* 
 * Casting ou changer type des variable*
 * utiliser opérateur de casting présiser le tipe entre parentaise avant la variable
 * 
 * diférent préfixe
 * (int) pour obtenire un type integer
 * (bool) pour obtenire un type boolean
 * (float) pour obtenire un type float
 * (string) pour obtenire un type string
 * (array) pour obtenire un type array
 * (object) pour obtenire un type object
 * (unset) pour obtenire un type null
 *  exemple
 */

$a = 10;
$b = (string)$a;
$c = "12";
if($b === $c){
    echo "B et du meme type que C<br>";
}else {
    echo "B n'est pas du meme type que C<br>";
}if($a === $b){
    echo "A et du meme type que B<br>";
}else {
    echo "A n'est pas du meme type que B<br>";
}
        ?>
    </body>
</html>





