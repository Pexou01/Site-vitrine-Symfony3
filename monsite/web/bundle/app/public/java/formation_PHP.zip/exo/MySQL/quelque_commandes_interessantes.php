<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
/**
* quelque commandes intéressantes
* 
* SHOW DATABASES;                affiche toure les base de donées
* 
* USE nom;                       selectione la base de données nom
* 
* SHOW tables;                                affiche les tables de la base de donées selectioné
* 
* CREATE DATABASE nom;                        creation de la base de donnée nom
* 
* CREATE TABLE nom[                         |
* champ1 type1(taille),                     | création de la table avecdeux 2 champ
* champ2 type2(taille),                     |
* ...]
* 
* DROP DATABASE nom;                          suprime la base de donnée nom 
* 
* DROP TABLE nom;                             surpime la table nom            
* 
* SELECT * FROM table;                        affiche tous les élément de la table spécifier
*  
* 
* SELECT * FROM table WHERE ch=valeur;        affiche tous les élément qui on la valeur indiqué 
*                                             dans la table spécifier
 * 
* SELECT * FROM table WHERE ch=valeur ORDER BY ch2 ASC; affiche tous les champs de la table specifier
*                                                      pour les quel le champ valeur et égale a ch
*                                                       classant les champ2 par ordre croissant
*/
        
/* 
* SELECT COUNT (*) FROM table;                conte le nombre d'enregistrement dans la table spécifier
* 
* DESCRIBE nom;                              donne les information de la table  nom
* 
* ALTER TABLE nom MODIFY(champ, type(taille)); modifie le type de données de la table nom
* 
* INSERT INTO nom VALUE(val1, ... etc);      rajoute a la fin de la table nom une ou plusieur valeur
* 
* UPDATE nom SET champ=valeur;               mes a jour le champ spécifier dans la table nom
* 
* UPDATE nom SET champ1=valeur1, champ2=valeur2, champ3=valeur3; mes a jour les valeur 1 et 2 et 3 
*                                                                de la table nom
* UPDATE nom SET champ=valeur WHERE champ2=valeur2; mes a jour les valeur qui sont egale a valeur 2 
*                                                   dans toute les valeur de la table nom
* 
* UPDATE nom SET champ1=valeur1, champ2=valeur2 WHERE champ3=valeur3;   MES A JOUR LES CHAMP 1 ET 2 
*                                                                      dans les enregistrement champ3
*                                                                      vaut 3 dans la table nom
* 
* DELETE FROM nom;           suprime les valeur du champs nom de la table et base selectioné
* 
* DELETE FROM nom WHERE champ=valeur;     suprime tous les enregistrement egale  a nom  
*                                         de la table nom
* 
* ROLLBACK        annule la supréssion d'enregistrement
* COMMIT          valide la supréssion d'enregistrement
* 
* 
*/
        ?>
    </body>
</html>
