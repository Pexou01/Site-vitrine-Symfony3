<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <!-- creation d'un tableau-->
<!--        <table></table>-->
<!-- <tr></tr> représente les ligne d'un tableau-->
<!--        <tr></tr>-->
<!-- <th></th> représente les célule de lentéte-->
<!--        <th></th>-->
<!-- <td></td> représente les autre colun-->
<!--        <td></td> -->
        <form name="form" method="post" action="traitement.php">
         <table>
<!--       ici le <tr> englobe le nom et input et les balises <td></td> englobe juste un champs exemple
                                        <tr><td>nom</td>
                                        <td><input></td></tr>

                                        <tr><td>nom</td>
                                        <td><input></td></tr>
--> 
        <th>Membre</th>
        <tr><td>nom</td>
        <td><input type="text" name="Nom" id="nom" value="Nom"></td></tr><br>
        <tr><td>Prénom</td>
        <td><input type="text" name="Prénom" id="prenom" value="Prénom"></td></tr><br>
        <tr><td>Password</td>
        <td><input type="password" name="Password" id="password" value="password"></td></tr><br>
        <tr><td>age</td>
        <td><select name="age" id="age"><br>
        <option > < 20</option>
        <option>20 à 50</option>
        <option>> 50</option>    
        </select></td></tr><br>
        <tr><td>zone de texte</td><br>
        <td><textarea cols="22" rows="4" id="textarea">Texte par default</textarea></td></tr><br>
        <tr><td><input type="submit" name="valider" id="valider" value="Valider"></td>
        <td><input type="reset" name="annuler" id="annuler" value="Annuler"></td></tr>
            </table>
	            </form>
        <?php
        // put your code here
        ?>
    </body>
</html>
