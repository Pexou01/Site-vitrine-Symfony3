<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * les requéte traditionel sur cette syntaxe
         * 
         * SELECT[un ou plusieur champs]FROM[une ou plusieur table]WHERE[une ou plusieur condition]
         * 
         * les jointure simple son mie dans les condition par contre les jointure compléxe se font entre le FROM et le WHERE
         * via des mots cléfs
         * INNER JOIN, LEFT JOIN, RIGHT JOIN 
         * Les jointure compléxe on donc une syntaxe diférente des jointures simple
         * 
         * SELECT [un ou plusieurs champs] FROM [une ou plusieurs tables][INNER | LEFT | RIGHT]JOIN [champ de jointure]
         * WHERE [une ou plusieurs conditions]
         * 
         * 
         * 
         * éxaminon une requéte INNER JOIN
         * 
         * La requéte SELECT simple
         * SELECT * FROM films, membre WHERE films.Film_Titre=membre.nom;
         * 
         * devient en jointure complexe
         * 
         * SELECT * FROM films INNER JOIN membre ON films.Film_Titre=membre.nom
         * 
         * seule la syntaxe change pas son comportement
         * 
         * 
         * 
         * éxaminon une requéte INNER JOIN
         * 
         * Les requéte de type LEFT JOIN son plus permisive que les autre requétes 
         * suposon qu'il existe plusieur enregistrement dans laa premiere table pour les quelle le champs
         * sur lequel céfectu la jointure ne sois pas rensségnier 
         * dans une jointure simple il seront juste ignoré
         * dans une jointure de type LEFT JOIN seront retenue mes la valeur null apparétera dans ces enregistrement éfectuer 
         * la jointure inssi que tous les champs de la desieme table 
         * 
         * La requete SELECT simple 
         * 
         * SELECT * FROM membre, films WHERE membre.nom=films.Film_Titre;
         * 
         * DEVIEN 
         * 
         * SELECT * FROM membre LEFT JOIN films ON membre.nom=films.Film_Titre;
         * 
         * 
         * 
         * éxaminon une requéte RIGHT JOIN
         * 
         * Les requéte de type RIGHT JOIN sont comparable au requéte LEFT JOIN 
         * suposon quil existe plusieur enregistrement dans la table 2 sur lequel le champ séfectue 
         * la jointure ne soi pas rensseignier dans une jointure simple elle sera ignoré 
         * dans une jointure de type RIGHT JOIN il seron retenu mes la valeur null sera indiqué quand le champ ou séfectu la jointure 
         * pareil dans la 2 eme table
         * 
         * la requéte SELECT simple
         * 
         * SELECT * FROM membre, films WHERE films.Film_Titre=membre.nom;
         * 
         * DEVIEN 
         * 
         * SELECT * FROM membre RIGHT JOIN films ON membre.nom=films.Film_Titre;
         *
         */         
        ?>
    </body>
</html>
