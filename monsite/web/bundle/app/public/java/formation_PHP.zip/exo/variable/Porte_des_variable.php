<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
        /**
         * les variable déclaré avant les fonction et les classe 
         * son utilisable partout en revenche si elle et déclaré dans une classe 
         * ou une fonction ou les boucle donc entre les { } sela veut dir que
         * les variable son utilisable que dans les fonction boucle ou classe 
         * et sans altéré la variable exterieur.  
         */
        $a = 10;
        function test(){
            // la global permet de la modifier et la lire partou la variable 
            global $a;
            //   ( \$a  le antislache permet daffiché le $ car sinon sa afficheré la valleur
            echo "Dans la fonction, \$a = ".$a."<br>";
            $a = 20;
        }
            echo "En dehors de la fonction, \$a = ".$a."<br>";
            test();
            echo "En dehors de la fonction, \$a = ".$a."<br>";
            
            /**
             * porté de la static
             */
            function test1(){
                // l'instruction statique serai executé une seul fois et gardera 
                // en memoire la valeur de la variable
                static $a =10;
                echo "\$a = ".$a."<br>";
                $a++;
            }
            test1();
             test1();
              test1();
               test1();
        ?>
    </body>
</html>
