<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         *  -> veut dire pointé la donnée ou le fichier 
         */
        
       /**
        * instanciation d'une classe (création d'un objet a partir d'une class)
        * 
        * (1)
        * on incére le code de la class avec
        * 
        * include_once(nom); 
        * nom représente le nom du fichier dans le quel a etais défini la class
        * 
        * (2)
        * crée un objet avec l'instruction NEW
        * 
        * $objet = new classe();
        * $objet et l'objet crée de la class et  le nom de la classe a utilisé comme model
        * 
        * (3)
        * pour accédé au méthode ou a une propiété public on utilise
        * 
        * $this->nom;
        * nom et le nom de la méthode ou de la propriété public a accédé
        * 
        * (4)
        * pour ajouté une valeur a une propriété public on fait
        * $this-> nomPropriete = 10;
        * 
        * (5) 
        * pour afficher une propriété on fait
        * echo $this->nomPropriete;
        * 
        * (6) 
        * pour lancer une fonction public avec
        * $this->nomFonction();
        * 
        * (7)
        * pour lancer une fonction avec des paramétre comme sa
        * $this->nomFonction("a","15","x");
        * 
        * (8)
        * pour affiché la valeur retourné d'une méthode public  on fait
        * echo $this->nomFonction();
        */
        ?>
    </body>
</html>
