<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
/**
* Les champs numériques
*  
* TYPE                SIGNIFICATION
* 
* tinyint          Occupe 1 octet peut stoké des nomre entiers compris entre -128 à 127
*                    si l'attribut UNSIGNED n'est pas spécifié ou compri entre 0 et 255 
*                    dans le cas contraire
* 
* smallint         Occupe 2 octets ce type de donnée peut stoker des nombre entier de -32768 à 32767
*                    si l'attribut UNSIGNED n'est pas spécifié ou compri entre 0 et 65535 
*                    dans le cas contraire
* 
* mediumint        Occupe 3 octets ce type de donnée peut stoker des nombre entier de -8388608 à 
*                    8388607 si l'attribut UNSIGNED n'est pas spécifié ou compri entre 0 et 16777215 
*                    dans le cas contraire
* 
* int              Occupe 4 octets ce type de donnée peut stoker des nombre entier de -2147483648 à 
*                     2147483647 si l'attribut UNSIGNED n'est pas spécifié ou compri entre 0 et 4294967295
*                    dans le cas contraire
* 
* bigint           Occupe 8 octets ce type de donnée peut stoker des nombre entier de -9223372036854775808 à 
*                    9223372036854775807 si l'attribut UNSIGNED n'est pas spécifié ou compri entre 0 et 
*                    18446744073709551615 dans le cas contraire
*                    
* 
* float            Occupe 4 octets ce type de donnée peut stoker des nombre flottans de présision simple  de -1.175494351E-38
*                     à 3.402823466E+38 si l'attribut UNSIGNED n'est pas spécifié ou compri entre 0 et 65535 
*                    3.402823466E+38 dans le cas contraire
* 
* double ou real   Occupe 8 octets ce type de donnée peut stoker des nombre flottant doble précision de -1.797693138623157E+308 
*                   à -2.2250738585072014E-308 si l'attribut UNSIGNED n'est pas spécifié ou compri entre 2.2250738585072014E-308
*                   et 17976931348623157E+308 vdans le cas contraire
* 
 */
        
/**
* Les champs chaine de caratére
* 
* TYPE                SIGNIFICATION
* 
* Char               Chaine de caractéres de taille fixe 
* Varchar           Chaine de caractéres de longeur variable comprise entre 1 et 255 caractéres
* Tinyblob          Chaine de 0 à 255 caractéres maximum (sensible à la casse)
* tinytext          Chaine de 0 à 255 caractéres maximum (insensible à la casse)
* Blob              Chaine de 0 à 65.535 caractéres maximum (sensible à la casse)
* Text              Chaine de 0 à 65.535 caractéres maximum (insensible à la casse)
* mediumblob        Chaine de 0 à 16.777.215 caractéres maximum (sensible à la casse)
* mediumtext        Chaine de 0 à 16.777.215 caractéres maximum (insensible à la casse)
* longblob          Chaine de 0 à 4.294.967.295 caractéres maximum (sensible à la casse)
* longtext          Chaine de 0 à 4.294.967.295 caractéres maximum (insensible à la casse)
*/
        
/**
* Les champs Date et heure
 * 
* TYPE           SIGNIFICATION
 * 
 * date         Occupe 3 octets Date au format AAA-MM-JJ entre 1000-01-01 et 9999-12-31
 * 
 * time         Occupe 3 octets Date au format AAA-MM-JJ entre 1000-01-01 et 9999-12-31
 * 
 * datetime     Occupe 8 octets Date et heure  au format AAA-MM-JJ HH:MM:SS entre 1000-01-01 00:00:00 
 *              et 9999-12-31 23:59:59
 * 
 * year         Occupe 1 octet A nnéee à 2 ou 4 ciffres entre 1901 et 2155 (4 chiffres) ou entre 
 *              1970 et 2069(2 chiffres)
 *              
 * timestamp    Occupe 4 octets Date codée sous une forme numérique et comprise entre 1970-01-01 00:00:00
 *              et l'année 2037
*/
        ?>
    </body>
</html>
