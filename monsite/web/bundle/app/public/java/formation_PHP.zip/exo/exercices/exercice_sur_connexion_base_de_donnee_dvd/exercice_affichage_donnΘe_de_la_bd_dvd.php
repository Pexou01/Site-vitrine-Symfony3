<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        try {
            $base = new PDO('mysql:host=localhost; dbname=dvd', 'root','');
} catch (exception $e) {
            die('Erreur '.$e->getMessage());
}
$base->exec("SET CHARACTER SET utf8");
$retour = $base->query('SELECT * FROM `membre`');
while ($data = $retour->fetch()){
echo "<table border : solid><th>Bonjour Mr ".$data['nom'].' '.$data['prenom']."</th><br>"
        .'<tr><td>Votre Adresse est : </td>'.'<td>'.$data['adresse']."</td></tr><br>"
        .'<tr><td>Votre Code Postale est : </td>'.'<td>'.$data['cp']."</td></tr><br>"
        .'<tr><td>Votre Date Anniversaire est le : </td>'.'<td>'.$data['date_anniversaire']."<br><br></td></tr><br></table>";
       
   }
   //afficher une recherche nom "Leblanc"
   $base = null;
    $base1 = new PDO('mysql:host=localhost; dbname=dvd', 'root','');
   $retour1 = $base1->query("SELECT * FROM membre WHERE nom='Leblanc'");
while ($data = $retour1->fetch()){
echo "<table border : solid><th>Bonjour Mr ".$data['nom'].' '.$data['prenom']."</th><br>"
        .'<tr><td>Votre Adresse est : </td>'.'<td>'.$data['adresse']."</td></tr><br>"
        .'<tr><td>Votre Code Postale est : </td>'.'<td>'.$data['cp']."</td></tr><br>"
        .'<tr><td>Votre Date Anniversaire est le : </td>'.'<td>'.$data['date_anniversaire']."<br><br></td></tr><br></table>";
       
   }
 $base = null;
        ?>
    </body>
</html>
