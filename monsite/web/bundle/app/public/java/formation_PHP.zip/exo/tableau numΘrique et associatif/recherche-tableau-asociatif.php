<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * recherche dans un tableu associatif
         */
        
        /**
         * exemple avec key exists
         * 
         * array_key_exists(clé, tableau)
         * qui retourne true si la clé existe sinon false
         */
        
         /* avec la fonction in_array
         * 
         * in_array(valeur, tableau) 
         * retourne true si la valeur existe sinon false
         /*
                     
         /**
          *  avec la fonction search
          * 
          * array_search(valeur, tableau)
          * retourne la clé corespondente a la valeur ou false si la 
          * valeur n'existe pas 
          */
        $calories = array("Pain au chocolat" => "410",
                          "Miel" => "304",
                          "Réglisse" => "377",
                          "Sorbet" => "90",
                          "Sucre" => "395",
                          "Cookies" => "464");
      
         $i = array_key_exists("Pain au chocolat", $calories);
         echo "$i<br>";
         
        ?>
    </body>
</html>
