<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * pour trier on utilise la fonction sort()
         */
        
        /**
         * exemple de type de tri  
         * SORT_NUMERIC = type numeric
         * SORT_REGULAR = sans modifier le TYPE DES ELEMENT
         * SORT_STRING =  type string
         * sort($tableau, SORT_NUMERIC|SORT_REGULAR|SORT_STRING);
         */
        
        ?>
    </body>
</html>
