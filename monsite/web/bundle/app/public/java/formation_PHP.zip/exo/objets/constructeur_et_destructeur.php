<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * les construteur et les destructeur son des méthode particuliere dite magique
         * elle permet réspectivement d'initialisé un objet l'aure de sa creation et déféctué les opération nécésaire l'aure de sa destruction
         * pour définir c'est deux méthode on fait comme sa 
         * 
         *   public function__construct(param1,param2,etc){
         *    une ou plusieur instruction
         *   }
         * 
         *   ET
         * 
         *   public function__destruct(){
         *    une ou plusieurs instruction
         *   }
         * 
         * exemple de contructeur
         * 
         *       public function__construct($texte,$entier){
         *       $this -> chaine = $texte;
         *       $this -> numérique = $entier;
         * 
         * exemple de destructeur 
         *      
         *       public function__destruct(){
         *          fclose($handle);
         *       }
         * 
         * toute les méthode magique commence par __ (2 anderscore)
         * 
         * autre méthode magique
         * 
         *   __call() 
         *   __callStatic()  
         *   __get() 
         *   __isset() 
         *   __unset() 
         *   __sleep() 
         *   __wakeup() 
         *   __toString() 
         *   __invoke() 
         *   __set_state() 
         *   __clone() 
         * 
         * pour plus d'info allez sur php.net/manual/fr/language.oop5.magic.php
         */
        ?>
    </body>
</html>
