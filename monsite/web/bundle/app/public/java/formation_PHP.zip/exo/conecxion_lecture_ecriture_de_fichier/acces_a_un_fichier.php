<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * il faut l'ouvrir avec la fonction $handle=fopen(nom,mode);
         * 
         * Ou:
         * 
         * handle est une variable qui représentera le fichier lorsque vous voudrez lire son contenu
         * ou y écrire des données;
         * 
         * nom est le nom du fichier;
         * 
         * mode est le mode d'accés au fichier .Les modes autorisés sont les suivants : 
         * r = lecture seul
         * r+ = lecture + écriture . si le fichier existe pas il est crée.
         * a = écriture seul . si le fichier existe pas il est crée.
         * a+ = écriture + lecture  . si le fichier existe pas il est crée.
         * 
         * aprés il faudra fermé le fichier avec
         * fclose($handle);
         */
        ?>
    </body>
</html>
