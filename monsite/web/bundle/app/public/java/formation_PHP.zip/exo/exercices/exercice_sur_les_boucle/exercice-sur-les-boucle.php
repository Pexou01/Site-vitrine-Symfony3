<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        //affiche un tableau en php
        echo"<table border>";
        // affiche l'antéte des colonnes du tableau
        echo"<tr><th>Nombre</th><th>Carré</th><th>Racine</th></tr>";
        // boucle for jusqua 11 ajoute 1 à chaque toure de boucle
        for ($i =1; $i<11; $i++)
            //affiche a chaque tour de boucle les valeur de $i jusqua que $i vaut 11 SQRT et le calcule de la racine
            echo "<tr><td>$i</td><td>".$i*$i."</td><td>".sqrt($i)."</td></tr>";
            echo "</table>";
        
        
        ?>
    </body>
</html>
