<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
          try {
            $base = new PDO('mysql:host=localhost; dbname=dvd', 'root','');
} catch (exception $e) {
            die('Erreur '.$e->getMessage());
}
$base->exec("SET CHARACTER SET utf8");
$retour = $base->query('SELECT membre.nom, films.Film_Titre FROM membre, films WHERE membre.id_code=films.id_code');
echo "<table>";
while ($data = $retour->fetch()){
echo $data['nom'].' '.$data['Film_Titre']."<br>";
   }
   echo "</table>";
 $base = null;
        ?>
    </body>
</html>
