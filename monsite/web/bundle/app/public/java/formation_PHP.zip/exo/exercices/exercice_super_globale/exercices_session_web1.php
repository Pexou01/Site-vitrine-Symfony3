 <?php
 session_start();
 ?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $prenom = htmlspecialchars($_POST["prenom"]);
        $nom = htmlspecialchars($_POST["nom"]);
       
        $_SESSION["nom"]=$nom;
        $_SESSION["prenom"]=$prenom;
        echo "Les données de se formulaire on etais enregistré";
        echo "<a href=\"exercices_session_web2.php\">Cliquer sur se lien pour verifier.</a>";
        
        ?>
    </body>
</html>
