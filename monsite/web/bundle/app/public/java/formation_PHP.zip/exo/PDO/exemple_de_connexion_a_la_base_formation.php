<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        try {
            $base = new PDO('mysql:host=localhost; dbname=formation', 'root','');
} catch (exception $e) {
            die('Erreur '.$e->getMessage());
}
$base->exec("SET CHARACTER SET utf8");
$retour = $base->query('SELECT * FROM `utilisateurs`');
while ($data = $retour->fetch()){
echo 'Bonjour Mr '.$data['nom'].' '.$data['prenom']."<br>"
        .'Vous vous connecté avec se login : '.$data['login']."<br>"
        .'Vous avez utilisé cette email : '.$data['email']."<br>"
        .'Votre mot de pass est : '.$data['password']."<br>"
        .'Votre numérpo client et le : '.$data['index']."<br><br>";
   }
 $base = null;
        ?>
    </body>
</html>
