<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * array_filter($tableau, fonction);
         * $tableau représente le tableau a filtrer
         * fonction représente la chaine nom d'une fonction apliqué a chaque élément du tableau
         * si la valeur et true alor elle et retenue sinon non
         */
        
        /**
         * exemple sur un tableau numéroté
         */
        function afficheImpaire($data){
            //pour afficher les nombre impaire ($data & 1 pour impaire ou 2 pour les paire)
            return($data & 1);
        }
        $tableau = array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        $tableau_filtre = array_filter($tableau, "afficheImpaire");
        foreach ($tableau_filtre as $element) {
            echo $element."<br>";
            
            
}
echo "<br>";
            // meme principe sur les tableau associatif avec la cle et les valeur
            $tableau1 = array("un"=>1, "deux"=>2, "trois"=>3);
            $tableau1_filtre = array_filter($tableau1, "afficheImpaire");
            foreach ($tableau1_filtre as $cle=>$valeur)
                echo $cle."<br>";
        ?>
    </body>
</html>
