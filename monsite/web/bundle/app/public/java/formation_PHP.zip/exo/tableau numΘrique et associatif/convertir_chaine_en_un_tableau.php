<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * exemple de convertion d'une chaine de caractaire en un tableau
         */
        /**
         * $tab = resultat de la conversion 
         * sep = le séparateur des élément de la chaine
         * ch représente la chaine a convertire
         * 
         * $tab = explode(sep, ch);
         */
        
        
        /**
         * exemple avec explode qui permet de transformé une chaine de caractaire 
         * en un tableau
         */
        
        $ch="Hydrogéne, Michel, Bore, Maison";
        $tableau = explode(",", $ch);
 
        ?>
    </body>
</html>
