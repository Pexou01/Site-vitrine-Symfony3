<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        include_once 'horloge.class.php';
        /**
         * création d'un client avec SoapClient
         * pour la sintaxe de SoapClient sur php.net
         */
        try{
            echo"le webservice donne l'heure";
            $clientSOAP = new SoapClient( null, 
                array(
                'uri' => 'http://localhost/',
                'location' => 'http://localhost/exo/exo/servicesweb/horloge.class.php',
                'trace' => 1,
                'exceptions' => 1
                ));
            // une foi le l'objet soapclient a etais instencier appel de la méthode heure de l'objet clientSAOP
            //pour plus d'info sur la fonction SAOP sur php.net
            $ret = $clientSOAP->__soapCall('heure', array());
            echo $ret;
        } 
        catch (SoapFault $f) 
        {
          echo $f;
        }
        ?>
    </body>
</html>
