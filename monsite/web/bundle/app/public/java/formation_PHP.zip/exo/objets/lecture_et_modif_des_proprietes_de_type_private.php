<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * par définition les type private ne peuve étre accédé que par les méthode de la class
         * dans l'aquel elle sont été défini pour sela on utilise des fonction public GETER ET SETER
         * 
         * Leur nom commence toujour par GET pour le GETER et SET pour les SETER
         * 
         * suposon que la propiété suivante sois défini dans la class
         * 
         * private $fyeo = "For Your Eyes Only";
         * 
         * pour pouvoir lire et modifier cette propriété puis une instanciation de la class
         * on doit définir les fonction getFyeo et setFyeo
         * 
         *        public function getFyeo(){   |  cette fonction lit le contenu de la propiété private $fyeo et le retourne à l'appelant
         *          return $this->fyeo;        |  
         *        }
         *  
         *        public funtion setFyeo(){    |   cette fonction Affecte la valeur qui lui est passée en paramétre à la propriété prive $fyeo
         *          $this->fyeo = $nouveau;    |
         */
        ?>
    </body>
</html>
