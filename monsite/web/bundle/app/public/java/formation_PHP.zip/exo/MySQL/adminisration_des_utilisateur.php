<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
/**
* USE mysql;
* SELECT * FROM user;     selection l'utilisateur de mysql
* SELECT * FROM mysql.user; et une variente de la premiere commande
* 
* USE mysql;
* SELECT host, user FROM user; affiche les champ host des utilisateur mysql 
* SELECT host, user FROM mysql.user et une variente de la desieme commande  
* 
* SELECT current_user(); affiche le nom sur l'utilisateur en cour
* 
* CREATE USER 'nom'@'serveur'; creation de l'utilisateur nom@serveur sans mot de pass sur le serveur spécifier
* 
* CREATE USER 'nom'@'serveur' IDENTIFIED BY 'p'; creation de l'utilisateur nom@serveur avec mot de pass p sur le serveur spécifier
* 
* GRANT ALL PRIVILEGES ON base.* 
* TO 'nom'@'serveur'                   donne a l'utilisateur nom sur sur le serveur spécifié 
* IDENTIFIED BY 'pass';                avec le mot de pass spécifié le droit d'accés a la base de donnée base
* 
* SHOW GRANTS;            affiche les droit du compte utilisé pour se conecté au serveur
*  
* DROP USER 'nom'@'base';   suprime l'utilisateur selectioné dans la base selectioné
* 
* SET PASSWORD FOR 'nom'@'base = PASSSWORD ('pass');  affecte le mot de pass 'pass' a l'utilisateur nom de la table spécifier
* 
*/ 
        ?>
    </body>
</html>
