<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * si la table existe on fait
         * tous dabort on fait une nouvelle instance pdo
         *  try {
         *   $base = new PDO('mysql:host=localhost; dbname=formation', 'root','');
         *   } catch (exception $e) {
         *   die('Erreur '.$e->getMessage());
         *   }
         * 
         * puis on crée une instruction comme sa
         * 
         * $base->exec("INSERT INTO nomTable VALUE('valeur1','valeur2',etc...)");
         * 
         * nomTable et le nom de la table ou ajoutér les valeurs
         * VALUE représente les valleur a indiqué l'aure de l'enregistrement en suposant que tous les champs sont rensseignier
         * 
         * sinom si vous ne remplicer pas tous les champs faie plutau comme sa
         * 
         * $base->exec("INSERT INTO nomTable (champ1, champ3, champ4)VALUE('valeur1', 'valeur3', 'valeur4')");
         * 
         * si on veut faire plusieur enregistrement on fait 
         * 
         * $base->exec("INSERT INTO nomTable (champ1, champ3, champ4)VALUES('valeur1', 'valeur3', 'valeur4'),
         * ('valeur1', 'valeur3', 'valeur4'),('valeur1', 'valeur3', 'valeur4')");
         * 
         */
        ?>
    </body>
</html>
