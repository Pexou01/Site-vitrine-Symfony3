<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         *  And ou &&   c'est le et logique 
         *  or ou || c'est ou logique
         * xor c'est un ou exclusif (test si une seule des deux expressions vaut TRUE)
         * ! c'est le non logique
         */
        ?>
    </body>
</html>
