<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        class miseEnForme{
             private $string = "Super tu à reussi à crée ton premier objet est à l'affichée.";
        
        public function __constructor($laCchaine){
            $this -> string = $chaine;
        }
        public function h1() {
            return "<h1>".$this->string."</h1><br>";
        }
        public function h2(){
            return "<h2>".$this->string."</h2><br>";
        }
        public function h3(){
            return "<h3>.".$this->string."</h3><br>";
        }
        public function italique(){
            return "<i>".$this->string."</i><br>";
        }
        public function gras(){
            return "<b>".$this->string."</b><br>";
        }
        }
        ?>
    </body>
</html>
