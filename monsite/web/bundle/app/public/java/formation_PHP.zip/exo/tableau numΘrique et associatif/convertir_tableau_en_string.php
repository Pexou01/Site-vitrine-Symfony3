<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * exemple avec la fonction implode()
         * 
         * spe = sépérateur
         * tableau = tableau a convertir
         * $chaine = implode(sep, tableau)
         * 
         */
        
        $e= array("Frederic", "Michel", "Jennifer", "Lysa");
        $chaine = implode(",", $e);
        foreach ($e as $value) {
            echo "$value<br>";
}
        ?>
    </body>
</html>
