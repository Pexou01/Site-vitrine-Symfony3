<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**différent opérateur
         *  + Addition $resultat = 10 + 5;
         *  - Soustraction $resultat = 10.2 - 5.4;
         *  * Multiplication $resultat = 5.1 * 6.2;
         *  / Division $resulta = 6 / 2.9;
         *  % Modulo ( reste de la division entiére) $resultat = 5 % 4;
         * 
         */
        $resultat = 10 + 5;
        $resultat1 = 10.2 - 5.4;
        $resultat2 = 5.1 * 6.2;
        $resultat3 = 6 / 2.9;
        $resultat4 = 5 % 4;
        
        echo "$resultat<br>";
        echo "$resultat1<br>";
        echo "$resultat2<br>";
        echo "$resultat3<br>";
        echo "$resultat4<br>";
        ?>
    </body>
</html>
