<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $sl = setlocale(LC_TIME, "FRA");
        setlocale(LC_TIME, $sl);
        echo strftime("Le %#d %B %Y est un %A", strtotime("10/01/2018"));
        ?>
    </body>
</html>
