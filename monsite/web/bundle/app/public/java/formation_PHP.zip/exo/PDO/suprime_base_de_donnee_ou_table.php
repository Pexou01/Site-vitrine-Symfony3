<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * 
         * on fait
         * $base = new PDO('mysql:host=localhost; dbname=basephp', 'root','');
         * $base->exec("DROP DATABASE basephp"); pour suprimé la base de donnée
         * $base->exec("DROP TABLE membrephp"); pour suprimé la table
         */
        ?>
    </body>
</html>
