<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        try {
            $base = new PDO('mysql:host=localhost; dbname=dvd', 'root','');
           } catch (exception $e) {
           die('Erreur '.$e->getMessage());
           }
          
           $base->exec("CREATE DATABASE basephp DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci");
            $base = null;
             try {
            $base = new PDO('mysql:host=localhost; dbname=basephp', 'root','');
           } catch (exception $i) {
           die('Erreur '.$i->getMessage());
           }
           $base->exec("CREATE TABLE `basephp`.`membrephp` ( `id`INT NOT NULL AUTO_INCREMENT,`nom`VARCHAR(50)NOT NULL,`prenom`VARCHAR(50)NOT NULL,`compteur_visite`SMALLINT NOT NULL,`dernier_visite`TIMESTAMP NOT NULL,INDEX(`id`))ENGINE=InnoDB;");
           $base->exec("INSERT INTO `membrephp`( `nom`,`prenom`,`compteur_visite`,`dernier_visite`) VALUES ('Dubur', 'Pierre', '34', NOW()),('Garnier','Chantal','128',NOW()),('Dupont','Jean','2',NOW()),('Vercor','Belle','45',NOW())");
           $retour = $base->query('SELECT * FROM `membrephp`');
while ($data = $retour->fetch()){
echo "<table border : solid><th>Bonjour Mr ".$data['nom'].' '.$data['prenom']."</th><br>
        </table>";
       
   }
           $base = null;
           
          
        ?>
    </body>
</html>
