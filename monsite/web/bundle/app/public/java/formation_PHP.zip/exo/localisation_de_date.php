<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * code et le code du pays recherche
         *  $sl = setlocale(LC_TIME, code);
         */
       
        /**
         * inisialization 
         */
        $s1 = setlocale(LC_TIME,"USA");
        setlocale(LC_TIME,$s1);
        echo strftime("Nous sommes le %A %#d %B %Y");
        ?>
    </body>
</html>
