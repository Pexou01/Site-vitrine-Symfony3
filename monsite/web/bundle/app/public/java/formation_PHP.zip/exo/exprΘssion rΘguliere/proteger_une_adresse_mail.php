<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * pour eviter que l'adresse soi choper par les robot qui parcour le net 
         * on utilise la fonction proteger exemple suis
         */
        
        function proteger($adr){
            $adresseCodee = "";
            // STRLEN permet de savoir le nombre de caractaire 
            for($i=0;$i<strlen($adr); $i++)
            //race a la fonction proteger la longeur de la chaine et parcouru avec substr
            // ord converti en caractaire ASCII
            $adresseCodee .= "&#" . ord(substr ($adr, $i, 1)) . ";";
        return $adresseCodee;
        }
       // la fonction proteger lui retourne une adresse email avec les caractaire ASCII
        echo "<a href='" . proteger("mailto:pexou01@gmail.com") .
                "'>Pour nous joindre, cliquez ici</a>";
        
        /**
         * si on observe le code dans la console sa donne sa 
         */ 
         
//  <html>
//  <head>
//  <meta charset="UTF-8">
//  <title></title>
//  </head>
//  <body>
//  <a href='&#109;&#97;&#105;&#108;&#116;&#111;&#58;&#112;&#101;&#120;&#111;&#117;&#48;
//  &#49;&#64;&#103;&#109;&#97;&#105;&#108;&#46;&#99;&#111;&#109;'>Pour nous joindre, cliquez ici</a> 
//  </body>
//  </html>

        
        ?>
    </body>
</html>
