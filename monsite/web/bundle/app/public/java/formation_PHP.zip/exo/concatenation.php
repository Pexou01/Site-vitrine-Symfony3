<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $millieu ="font";
        $fin =15;
        //exemple d'affichage de variable avec les ""
        echo "Trois fois cinq $millieu $fin<br>";
        // exemple avec '' mes qui affiche le nom des string
        echo 'Trois fois cinq $millieu $fin<br>';
        // ou encore avec '' pour afficher le contenu des variable
        echo 'Trois fois cinq'.' '.$millieu.' '.$fin.'<br>';
        ?>
    </body>
</html>
