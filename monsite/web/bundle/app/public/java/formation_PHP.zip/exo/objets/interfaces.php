<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * en programation objet l'interface perméte d'indiqué quel methode public une classe doit implémenté
         * leur principal intéré de garantire toute les class quil inplémente donneron accée au méthode spécifier dans l'interface
         * l'utilisation d'interface trouve son utilité dans les projet avec plusieur programmeur ou développer en modulaire 
         */
        /**
         *    mise en place de l'interface formationPHP     
         */
        interface formationPHP{
            // l'interface implémente les methode public programe est pratique
            public function programme();
            public function pratique();
        }
        /**
         * definir 2 class qui implémente l'interface formationPHP
         * dans le fichier debutant.class.php et debutant.class.php
         * et pour finir l'exemple on fait un 4 eme fichier appeler formation.php
         * pour teste le code de interfaces.php ,  debutant.class.php et debutant.class.php
         */
        ?>
    </body>
</html>
