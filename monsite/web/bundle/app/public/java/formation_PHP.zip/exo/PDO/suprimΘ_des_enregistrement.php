<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
       /**
        * pour suprimer des enregistrement on fait 
        * 
        * DELETE FROM table WHERE condition;
        * 
        * table et le nom de la table ou suprimé l'élément
        * condition et la condition pour suprime le ou les enregistrement
        */
        ?>
    </body>
</html>
