<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * la close HAVING permet d'appliqué un critaire suplémentaire sur une clause GROUP BY
         * exemple pour affiche la moyenne des frais de port par pays et que la moyenne sois > 50 on utilise
         * 
         * SELECT ShipCountry, AVG(Freight) AS port_moyen
         *  FROM orders
         *  GROUP BY ShipCountry 
         * HAVING port_moyen >50
         */
        ?>
    </body>
</html>
