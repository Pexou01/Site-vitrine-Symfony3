<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <p>Ce text et fait par le client</p><br>
        <?php
        /*
         * plusieur test
         * 
         * is_array() test si c'est un tableau
         * is_bool() test si c'est un boolean ( true / false )
         * is_foalt() test si c'est un nombre réel 
         * is_int() test si c'est un nombre entier 
         * is_null() test si c'est null
         * is_numéric () test si c'est un numérique
         * is_object() test si c'est un odbject
         * is_string() test si c'est une string 
         */
  $ch =[12];
  if (is_array($ch)){
      echo " c'est un tableau<br>";
        } else {
             echo "c'est pas un tableau<br>";
        }
        
        /**
         * Autre test avec une boucle if
         */
        $f = 15;
        $g = 11;
        $s = 15;
        
        echo "F $f<br>";
        echo "G $g<br>";
        echo "S $s<br>";
        
        if ($f < $g){
            // si la valleur $f est inférieur à $g alor fait une ou plusieur instruction
            echo 'F et inférieur   à G<br> ';
            // si la valeur $f est supérieur à $g alor fait sa
        }else {
            echo 'F et supérieur à G<br>';
        }
        if ($f == $s){
            echo 'F et égale à S<br> ';
        }else {
            echo 'F et pas égale à S<br>';
        }
        if ($g != $s){
            echo 'G et différent de S<br> ';
        }else {
            echo 'F et pas différent de S<br>';
        }
        if ($s > $g){
            echo 'S et supérieur à G<br> ';
        }else {
            echo 'S et inférieur à G<br>';
        }
        // test  sur la variable $i 
        $i = 1;
        switch ($i){
            // si la valeur est zero alor execute sa
            case 0:
                echo "i vaut 0<br>";
                // break met fin à linstruction
                break;
            // si la valeur est un alor execute sa
            case 1:
                echo "i vaut 1<br>";
                break;
            // si la valeur est deux alor execute sa
            case 2:
                echo "i vaut 2<br>";
                break;
        }
        /**
         * le test suivant test si $a est égale à 15  
         */
        $a = 15;
        if ($a == 15)
            $b = "$a A est égale à 15<br>";
        else 
            $b = "$a  A est différent de 15<br>";
                    
        $b = ($a == 15) ?"$a A est égale à 15" : "$a  A est différent de 15<br>";
        echo "$b";
        ?>
    </body>
</html>
