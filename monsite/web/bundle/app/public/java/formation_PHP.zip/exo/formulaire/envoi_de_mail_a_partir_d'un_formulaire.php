<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * pour envoyer un mail a partir d'un fichier php on utilise la function mail
         * exemple de code 
         * 
         * $resultat = mail(destin,titre,texte,de);
         * destin = est l'adresse du destinataire du message
         * titre = est le titre du message
         * texte = est le texte (brut ou html)envoyer dans son corps du message
         * 
         * de = est l'entét" du message composée des élément 
         * suivants séparé entre eux par un retour chariot(\n):
         * l'adresse mail de l'émeteur du message
         * le type MIME du message
         * le type de contenu
         * le charset utilisé dans le message
         */
        
        /**
         * exemple de code
         */
        // DANS UN PREMIER TEMP ON SAUVEGARDE LES DONNEE  DANS DES VARIABLE $titre $texte $destinataire $delapartde et $from
        $titre ="Envoi de mail par PHP";
        $texte = "<font-color=\"red\">Ce mail a été envoyé depuis <b>un script PHP</b>.</font>";
        $destinataire = "pexou01@gmail.com";
        $delapartde = "pexou01@live.fr";
        // le non de l'expéditeur 
        // toute les information son serparé par un retour charriot (\n)
        $from = "From:".$delapartde."\n";
        // version du message
        $from .= "MIME-version: 1.0\n";
        //type du message avec son encodage (uft8) 
        $from .= "Content-type: text/html; charset= UTF-8\n";
        // envoi du mail si une erreur c'est produite alor affiche sa
        if (!mail($destinataire, $titre, $texte, $from))
            echo "Un probléme s'est produit lors de l'envoi du message. Recommencez SVP";
        ?>
    </body>
</html>
