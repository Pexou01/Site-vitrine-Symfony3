<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $tab = array("Miel" => "304", "Réglisse"=> "377", "Sorbet"=> "90", "Sucre"=> "396", "Cookies"=> "464");
         /**
         * tri des clef par ordre croissant  des clef
         */
         ksort($tab);
        foreach ($tab as $key => $value) {
        echo "$key"." "."$value<br>";
}
                                
echo "<br>";
        /**
         * tri des clef  par ordre croissant des valeur
         */
         asort($tab);
        foreach ($tab as $key => $value) {
        echo "$key"." "."$value<br>";
}
        ?>
    </body>
</html>
