<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $dateEtHeure1 = "15 juin 2014 20:12:15";
        $rest = substr($dateEtHeure1, -8);    
        $pos = strpos($dateEtHeure1, "2"); 
              echo "$rest.$pos<br>";
              
              /**
               * corigé
               */
              //récupaire la position  et enregistre dans la variable $premierEspace du premier espace
              $premierEspace = strpos($dateEtHeure1," ");
              //récupaire la position et enregistre dans la variable $deuxiemeEspace du deusieme espace
              //le troiseme parametre ($premierEspace+1) et la position ou commence la recherche
              $deuxiemeEspace = strpos($dateEtHeure1," " ,$premierEspace+1);
              //récupaire la position et enregistre dans la variable $troisiemeEspace du troisieme espace
              $troisiemeEspace = strpos($dateEtHeure1," ", $deuxiemeEspace+1);
              //récupaire la position et enregistre dans la variable $premierDeuxPoints du premier deux point
              $premierDeuxPoints = strpos($dateEtHeure1,":");
              //récupaire la position et enregistre dans la variable $desiemeDeuxPoints du dexieme deux point
              $dexiemeDeuxPoints = strpos($dateEtHeure1,":",$premierDeuxPoints+1);
              
              // extrai et affiche le jour donc 15
              echo "Jour = ".substr($dateEtHeure1,0,$premierEspace)."<br>";
              // extrai et affiche le mois donc juin
              echo "Mois = ".substr($dateEtHeure1, $premierEspace+1, $deuxiemeEspace-$premierEspace)."<br>";
              // extrai et affiche le anée donc 2014
              echo "Anées = ".substr($dateEtHeure1, $deuxiemeEspace+1, $troisiemeEspace-$deuxiemeEspace)."<br>";
              // extrai et affiche l'heure donc 20
              echo "Heure = ".substr($dateEtHeure1, $troisiemeEspace+1, $premierDeuxPoints-$troisiemeEspace-1)."<br>";
              // extrai et affiche les minutes donc 12
              echo "Minutes = ".substr($dateEtHeure1,$premierDeuxPoints+1, $dexiemeDeuxPoints-$premierDeuxPoints-1)."<br>";
              // extrai et affiche les seconde donc 15
              echo "Seconde = ".substr($dateEtHeure1,$dexiemeDeuxPoints+1, strlen($dateEtHeure1) - $dexiemeDeuxPoints)."<br>"
        ?>
    </body>
</html>
