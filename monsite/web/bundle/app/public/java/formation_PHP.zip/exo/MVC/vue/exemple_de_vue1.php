<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Accees a la table membre de la base de donnée dvd</title>
        <style>
            th{ padding-right: 30px;}
        </style>
    </head>
    <body>
        <?php
        echo "<table border><tr><th>Order</th><th>nom</th><th>prenom</th></tr>";
        foreach($donnees as $ligne){
            echo "<tr>";
            for($i=0; $i<13;$i++)
                echo "<td>".$ligne[$i]."</td>";
            echo "</tr>";
        }
        echo "</table>";
        ?>
    </body>
</html>
