<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Utilisation des classes debutant et avance</title>
    </head>
    <body>
        <?php
        // include_once référence les fichier debutant.class.php et avance.class.php
        include_once ("debutant.class.php");
        include_once ("avance.class.php");
        
        // les objet $coursDebutant et $coursAvance sont crée en instanciant les class debutant et avance
        $coursDebutant = new debutant;
        $coursAvance = new avance;
        //le texte qui suis et afficher en gras
        echo "<b>Formation pour débutants PHP</b><br>";
        // puis le mot Programme et afficher en italique
        echo "<i>Programme :</i><br>";
        // invocation de la méthode programme de la class coursDebutant les notion abordé son alor affiché retourné par la methode programme
        echo $coursDebutant->programme();
        // puis le mot Pratique et afficher en italique
        echo "<i>Pratique :</li><br>";
        // puis les methode pratique de l'objet $coursdebutant
        echo $coursDebutant->pratique();
        
        echo "<br><b>Formation avancée PHP</b><br>";
        echo "<i>Programme :</i><br>";
        echo $coursAvance->programme();
        echo "<i>Pratique :</li><br>";
        echo $coursAvance->pratique();
        ?>
    </body>
</html>
