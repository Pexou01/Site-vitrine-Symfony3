<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
      
        
        /**
         * exercice avec un foreach et explode qui permet de transformé une chaine de caractaire 
         * en un tableau
         */
        
        $ch="Hydrogéne, Michel, Bore, Maison";
        $tableau = explode(",", $ch);
        foreach ($tableau as $value) {
            echo "$value<br>";   
}
        ?>
    </body>
</html>
