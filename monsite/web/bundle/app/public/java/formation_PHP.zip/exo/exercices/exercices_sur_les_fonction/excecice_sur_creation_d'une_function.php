<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        //Racine d'une équation du second degré avec 3 parametre
        
        function racine($a,$b,$c){
            echo"recherche des solution de l'équation $a x + $b x + $c<br>";
            $delta = $b*$b - (4 * $a * $c);
            // si la fonction et negatif il affiche se message
            if ($delta < 0)
                echo "Cette équation n'a pas de solution";
            //si la fonction et egale a 0 elle affiche sa
            if ($delta == 0)
                echo "Cette equation a une racine double égale a ".-$b/(2*$a);
            // et si elle et positif alor elle affiche sa
            if ($delta > 0){
                $racine1 = (-$b - sqrt($delta))/(2*$a);
                $racine2 = (-$b - sqrt($delta))/(2*$a);
                echo "Cette équation a deux racines : $racine1 et $racine2";
            }
        }
        racine(1, 2, 3);
        ?>
    </body>
</html>
