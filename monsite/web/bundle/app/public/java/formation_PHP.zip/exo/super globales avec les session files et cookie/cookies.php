<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
/**
 * les cookies se déclre avant le doctype!
 * il on une durée de vie programable et son propre à chaque utilisateur
 * 
 * pour mémoriser un cookies on utilise la foncion :
 * setcookie(nom, valeur, expiration, chemin, domaine, securité, httponly);
 * 
 * nom = le nom du cookie. 
 * 
 * valeur =  la valeur à mémoriser dans le cookie. 
 * 
 * expiration = le temps aprés lequel le cookie n'est plus valide. au parametre time(time+30*24*3600)
 * 
 * chemin = le chemin sur le serveur sur lequel le cookie doit étre disponible (/ enssemble du domaine)
 *                                                                         (rep pour limité au dossier)
 * domaine = le domaine ou le cookie est disponible (www.mondomaine.fr par exemple)
 * 
 * securité = indique si le cookie doit étre transmis à travers une connexion sécurisée.(conection https)
 *                                                                                      (TRUE OU FALSE)
 * httponly = idique si le  cookie ne doit étre accessible que par le protocole http.(protocole http)
 *                                                                                      (TRUE OU FALSE)
 * exemple de sauvegarde du cookie membre
 * 
 */         
setcookie("prenom", "frederic", time()+3600, "", "", FALSE, TRUE);

/**
 * pour affiché tous les cookie de l'ordinateur on fait
 */
var_dump($_COOKIE);
/**
 * pour affiché un cookie donnée on fait
 */
echo $_COOKIE["nom"]; //nom et le nom du cookie
/**
 * pour suprimé un cookie on fait
 * cest pareil que sauvegarde mes faut métre une valeur négative
 */
setcookie("prenom", "frederic", time()-3600, "", "", FALSE, TRUE); 
        ?>
    </body>
</html>
