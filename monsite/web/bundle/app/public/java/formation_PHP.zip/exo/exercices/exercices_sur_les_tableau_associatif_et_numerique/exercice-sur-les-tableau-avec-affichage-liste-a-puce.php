<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * creation de la liste à puce avec une boucle for
         * echo <ul> affiche la liste à puce 
         */
        
        echo "<ul>";
        //tableau de nom
        $tab1 = array("Jean", "Pierre", "Paul", "Michel", "Héléne", "Sandrine",
           "Cristel", "Isabelle", "Evariste");
        /**
         * boucle for pour boucler sur la longeur du tableau avec l'option count($tab1)
         */
        for ($i = 0; $i < count($tab1); $i++)
        /**
         *  afficle une nouvelle entrée à chaque fois que la boucle se fait 
         * et temp que $i et inferieur à la longeur du tableau
         */
            echo "<li>$tab1[$i]</li>";
            
        
                 echo "</ul>";
        ?>
    </body>
</html>
