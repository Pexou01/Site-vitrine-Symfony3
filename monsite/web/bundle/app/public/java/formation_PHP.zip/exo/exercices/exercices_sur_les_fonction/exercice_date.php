<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
       if (date("j") ==1)
           //si c'est le premier jour affiche sa
           echo date("\C\'\\e\s\\t \l\\e j\\e\\r \j\o\u\\r \d\u \m\o\i\s.");
       else 
           //sinon affiche sa
           echo date("\C\'\\e\s\\t \l\\e j\ \é\m\\e \j\o\u\\r \d\u \m\o\i\s.")

        ?>
    </body>
</html>
