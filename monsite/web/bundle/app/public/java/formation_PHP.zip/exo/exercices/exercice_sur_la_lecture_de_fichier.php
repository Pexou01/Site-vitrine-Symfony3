<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $handle=fopen("data.txt","r");
    
    if ($handle){
      $ligne = fgets($handle);
    $ligne .= fgets($handle);
    $ligne .= fgets($handle);
    $ligne .= fgets($handle); 
    echo $ligne."<br>";
    }
    /**
     * ou
     */
    $handle1=fopen("data.txt","r");
    while(!feof($handle1))
        echo fgets($handle1."<br>");
    fclose($handle1);
        ?>
    </body>
</html>
