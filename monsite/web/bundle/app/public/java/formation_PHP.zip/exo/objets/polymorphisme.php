<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * peu utile en PHP
         */
         
        /**
         * suposon que la class laser et 3 class dérivé cd dvd et blue 
         * les 3 class dérivé on les meme caracteristique de laser 
         * du coup les cd dvd et blue peuve etre trété comme un objet laser
         * il et possible de surcharger la class parent pour avoir un comportement diférent d'elle
         */
        class Laser {
            public function caracteristiques() {
                echo "Disque laser<br>";
            }
        }
        class CD extends Laser{
            public function caracteristiques() {
                //exemple de surcharge de la classe parent et la compléte avec ces données
                parent::caracteristiques();
                echo "Capacité : 700Mo<br>";
            }
        }
        class DVD extends Laser{
            public function caracteristiques() {
                //exemple de surcharge de la classe parent et la compléte avec ces données
                parent::caracteristiques();
                echo "Capacité : 4,7 Go<br>";
            }
        }
        class Blue extends Laser{
            public function caracteristiques() {
                //exemple de surcharge de la classe parent et la compléte avec ces données
                parent::caracteristiques();
                echo "Capacité : 25 Go<br>";
            }
        }
                ?>
    </body>
</html>
