<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * si on affiche t'elle quel cela va m'afficher le message d'alert
         * si on veut eviter sa on utilise une fonction echapement pour eviter se que l'utilisateur fait
         * 
         * exemple de fonction
         * 
         * htmlspecialchars() qui transforme les caractaire speciau en entité HTML 
         * EXEMPLE UN & comercial deviendra &amp,
         * 
         * exmple d'une autre fonction
         * htmlentities() permet de transfomé meme se  modifier par htmlspecialchars en entité HTML 
         */
        
        $saisie = "<script>alert('Le vengeur masqué est sur le point de formater votre disque !!!');</script>";
                echo $saisie;
             
// Le code suivant permet d'affiché les balise html sans altéré le code 
    echo htmlspecialchars($saisie, ENT_QUOTES);
    
      
                ?>
    </body>
</html>
