<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * 
         */
        
        $nombre = array(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20);
       //melange automatiquement les élément du tableau passée en argument
        shuffle($nombre);
        foreach ($nombre as $element){
            echo $element.", ";
        }
        ?>
    </body>
</html>
