<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * il est possible de crée un nouveau type d'objet en prenant comme modéle un type objet déja existant
         * 
         * le nouvel objet possédera (héritera)les méme proriétés et les même méthodes que son modéle
         * 
         * le nouvel objet et un objet dérivé ou un descendant de l'ancien
         */
        ?>
    </body>
</html>
