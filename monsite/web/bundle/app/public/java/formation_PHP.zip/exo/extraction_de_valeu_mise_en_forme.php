<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * la fonction sscanf() permet d'extraire des donnée d'une chaine 
         * en utilisen avec une ou plusieur mise en forme
         */
        
        /**
         * exemple de syntaxe
         * 
         * sscanf(chaine,directives,vex1,...);
         *  ici chaine contier la chaine a extraire
         *  directive et une chaine qui contien 1 ou plusieur directive de mise en forme
         * les directive son identique a celle de la mise en forme
         * vex1 et (... si plusieur vex) sont les valeur extrai en fonction 
         * des param choisi dans le desiemme parametre
         */
        
        /**
         * exemple de code ou on extrai 3 donnée que lon stocke dans les variable $jour $mois $annee et mes en forme et apres on affiche
         */
        $uneDate = "12/08/2013";
        sscanf($uneDate, "%d/%d/%d", $jour, $mois, $annee);
        echo"Jour : ".$jour.", Mois : ".$mois." , Année : ".$annee;
        ?>
    </body>
</html>
