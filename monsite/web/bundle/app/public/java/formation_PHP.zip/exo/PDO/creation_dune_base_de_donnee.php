<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * tous dabort on fait une nouvelle instance pdo
         *  try {
         *   $base = new PDO('mysql:host=localhost; dbname=formation', 'root','');
         *   } catch (exception $e) {
         *   die('Erreur '.$e->getMessage());
         *   }
         * 
         * puis on crée une instruction comme sa 
         * 
         * $base->exec("CREATE DATABASE nom DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci");
         * 
         * nom et le nom de la base de donnée a créer
         * DEFAULT CHARACTER SET représente le jeu de caractére a utiliser dans la table par default
         * COLLATE représente l'intérclassement ou la colation du jeu de caractére
         */
        ?>
    </body>
</html>
