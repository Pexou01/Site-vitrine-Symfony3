<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // include_once fait référence au fichier qui contien la class 
        include_once("exercice_sur_les_class_et_creation_objet_2.php");
        $string = new miseEnForme("Super tu à reussi à crée ton premier objet est à l'affichée.");
        echo "Chaine de caractére en H1 = ".$string->h1()."<br>";
        echo "Chaine de caractére en H2 = ".$string->h2()."<br>";
        echo "Chaine de caractére en H3 = ".$string->h3()."<br>";
        echo "Chaine de caractére en ITALIQUE = ".$string->italique()."<br>";
        echo "Chaine de caractére en GRAS = ".$string->gras()."<br>";
        ?>
    </body>
</html>
