<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * Qu'est-ce que MVC et pourkoi L'utiliser?
         * sur les grand projet il et important de bien structuré le code
         * mvc et un disign patherne un modéle de conception qui permet de structuré son code en 3 partie bien précise
         * 
         * Modéle cette partie gére les donée du site elle récupére les donnée grace a des commande SQL et les met en forme pour
         * quel puisse etre trété par la partie controleur
         * 
         * Vue cette partieest dédiée à l'affichage sur l'écran elle est généralement composé d'un mélange html et php
         * 
         * Controleur cette partie contient la portion "intelligente" du code elle recois les données du visiteur demande 
         * au model de touvé des donées corespondante dans la base de donée analize les données fourini par le model et
         * decide se qui doit etre afficher sur la partie vue
         * 
         * en suivant les directive des stucture mvc quel fichier crée et quel role leur donées
         */
        ?>
    </body>
</html>
