<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
       
        class chaineplus{
            //premiere instruction private affecte une string a $chaine accécible que par les methode de la classe
        private $chaine = "Programation orientée objet en PHP";
        
        public function __constructor($laCchaine){
            $this -> chaine = $chaine;
        }
        //les instruction suivante son les methode gras italique souligne et majuscule
        
        // pour la methode gras on appel la chaine et on lui rajoute les balise "<b></b>" et <br> pour le rertour a la ligne
        public function gras(){
            return "<b>".$this->chaine."</b><br>";
        }
        // pour la methode italique on appel la chaine et on lui rajoute les balise "<i></i>" et <br> pour le rertour a la ligne
        public function italique(){
            return "<i>".$this->chaine."</i><br>";
        }
        // pour la methode souligne on appel la chaine et on lui rajoute les balise "<u></u>" et <br> pour le rertour a la ligne
        public function souligne(){
            return "<u>".$this->chaine."</u><br>";
        }
        // pour la methode majuscule on appel la chaine et on lui rajoute la fonction strtoupper($this->chaine)et <br> pour le rertour a la ligne
        public function majuscule(){
            return strtoupper($this->chaine)."<br>";
        }
        }



     
        ?>
    </body>
</html>
