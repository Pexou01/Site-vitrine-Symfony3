<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * exemple tous simple qui retourne heure utc
         * dans un premier temps on défini la classe horloge avec un seul methode public heure avec en retour la fonction date
         */
        class horloge{
            public function heure() {
                return date("e H:i:s");
            }
        }
        
        /**
         * pour la métre en place il faut faire
         * aide sur soapserver sur php.net
         * instruction se fait dans un try catch
         */
        try{
            // création de lobjet en précisent l'addresse uri du fichier qui contien la class 
            $server = new SoapServer(null, array('uri' => 'http://localhost/exo/exo/servicesweb/horloge.class.php'));
           // indique le nom de la class qui gére les requete soap
            $server->setClass("horloge");
            // gere toute les tache et requéte de soap
            $server->handle();
            // si ya une erreur alor il affiche sa
        } catch (Exception $e) {
            echo "Exception: " . $e;
        }
        ?>
    </body>
</html>
