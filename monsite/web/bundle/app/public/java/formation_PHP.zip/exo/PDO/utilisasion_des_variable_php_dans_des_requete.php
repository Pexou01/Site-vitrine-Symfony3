<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * utilisation de variable php des les requétes
         * on utilise des requete preparé
         * 
         * exemple
         * 
         * $retour=$base->prepare('requéte');
         * ici requéte est une requéte mysql qui contien 1 ou plusieur ?
         * 
         * exemple
         * 
         * SELECT*FROM base WHERE champ1=? AND champ2=?
         * les ? seront renplacer par les valeur l'aure de la methode execute
         * 
         * $retour->execute(array($var1, $var2));
         * 
         */
        ?>
    </body>
</html>
