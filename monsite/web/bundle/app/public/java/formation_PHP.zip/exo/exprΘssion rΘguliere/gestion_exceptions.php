<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * Le code qui peut provoquer une exception doit être entouré d'une structure try
         * 
         * Une exception peut etre déclenchée par une instruction suivante
         * throw new Exception("message");
         * 
         * L'instruction catch(exception $e) permet de capturer une exception
         * chaque instruction try doit avoir une instruction catch corespondante
         */
        
        /**
         * exemple de gestion exception
         */
        
        // création de la function inverse
        function inverse($nombre){
            //si le nombre et égale a zero 
            if ($nombre == 0)
                //  exception ("division par zéro") et généré
                throw new Exception("division par zéro");
            else 
                // dans le cas inverse il retoure le nombre
                echo "1/$nombre = ".(1/$nombre)."<br>";
                    }
                    // les instruction qui ne sont pas sur sont mi dans le try
                    try{
                        // ici calcule la fraction 
                        echo inverse(12);
                        // ici la fraction provoque un message d erreur car egale a 0 donc cree une exception
                        echo inverse(0);
                        // ici la 3 eme fraction n'est pas executé car le programe c'eest arrété
                        echo inverse(3);
                        // quant une exception se produit alor le catch et exécuté puit le programe s'intéron
                    } catch (Exception $e) {
                        echo "Une exception a été générée : ".$e->getMessage()."<br>";
                    }
                    /**
                     * sela affiche du coup le premier cas et pour le 2 eme cas 
                     */
        ?>
    </body>
</html>
