<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form name="form" method="post" action="exercice_sur_les_cookies1.php">
            <table>
                <th>Membre</th>
                <tr><td>nom</td>
        <td><input type="text" name="nom" id="nom" value="Nom"></td></tr><br>
        <tr><td>Prénom</td>
        <td><input type="text" name="prenom" id="prenom" value="Prénom"></td></tr><br>
        <tr><td><input type="submit" name="envoyer" id="valider" value="Envoyer"></td>
            </table>
        </form>
    </body>
</html>
