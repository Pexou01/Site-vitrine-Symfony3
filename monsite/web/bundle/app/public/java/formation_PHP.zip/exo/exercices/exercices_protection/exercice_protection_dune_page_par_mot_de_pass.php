<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        if (isset($_POST['mdp']) AND $_POST['mdp'] ==  "1234") // Si le mot de passe est bon
{
// On affiche les codes
$prenom = htmlspecialchars($_POST["prenom"]);
        $nom = htmlspecialchars($_POST["nom"]);
        $motdepass = htmlspecialchars($_POST["mdp"]);
        $age = htmlspecialchars($_POST["age"]);
        $obs = htmlspecialchars($_POST["observations"]);
        
        echo "<b>Donnée recues :</b><br><br>";
        echo "Prenom : $prenom<br>";
        echo "nom : $nom<br>";
        echo "Mot de passe : $motdepass<br>";
        echo "age : $age<br>";
        echo "observations : $obs<br>";
}
else // Sinon, on affiche un message d'erreur
{
    echo "Mot de passe incorecte";
}
        ?>
    </body>
</html>
