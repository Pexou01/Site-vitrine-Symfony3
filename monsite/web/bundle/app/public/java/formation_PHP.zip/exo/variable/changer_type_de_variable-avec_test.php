<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
/* 
 * Casting ou changer type des variable*
 * utiliser opérateur de casting présiser le tipe entre parentaise avant la variable
 * 
 * diférent préfixe
 * (int) pour obtenire un type integer
 * (bool) pour obtenire un type boolean
 * (float) pour obtenire un type float
 * (string) pour obtenire un type string
 * (array) pour obtenire un type array
 * (object) pour obtenire un type object
 * (unset) pour obtenire un type null
 *  exemple
 */

$a = 10;
$b = (string) $a;
$c = "12";
// test sur le type 
if($b ===$c){
    echo "B et du meme type que C<br>";

// test sur le type    
}if($a === $b){
    echo "A et du meme type que B<br>";
}else {
    echo "A n'est pas du meme type que B<br>";
}
        ?>
    </body>
</html>
