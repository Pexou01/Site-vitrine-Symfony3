<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * exemple de superglobales
         * $_GET[] , $_POST[] , $_FILES[]
         * 
         * superglobales           signification
         * 
         * $_GLOBALS            Tableau assosiatifs de toute les vatirable globales du script
         *                      (les nom des variable sont les index du tableau)
         * 
         * $_SERVER             Tableau associatifs crée par le serveur et contenent différenetes 
         *                      information comme les en-téte, dossier et chemin du script
         *                      pour plus d'info va sur la doc de php.com
         * 
         * $_COOKIE             Tableau associatif des cookies enregistré sur l'ordi du client
         * 
         * $_SESSION            Tableau associatif des valeur stockee sur le serveur pour 
         *                      la session d'un utilisateur
         * 
         * $_ENV                Tableau associatif de variables d'environement du serveur 
         *                      Cette superglobal n'est que trés peu utilser
         * 
         *  pour afficher les superglobale on utilise la fonction var_dump($_SERVER)
         */
        var_dump($_SERVER);
        ?>
    </body>
</html>
