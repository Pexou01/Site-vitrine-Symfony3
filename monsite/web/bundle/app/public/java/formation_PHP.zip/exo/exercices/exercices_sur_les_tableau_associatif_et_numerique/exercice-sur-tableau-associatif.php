<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        //tableau associatif
        $tab = array("H" => "Hydrogéne",
                     "He" => "Helium",
                     "Li" => "Lythium",
                     "Be" => "Beryllium",
                     "B" => "Bone",
                     "C" => "Carconne",
                     "N" => "Azote",
                     "O" => "Oxygéne",
                     "F" => "Fluor",
                     "Ne" => "Néon");
        /**
         * affiche dans un tableau les donnée du tableau $tab avec la balise <table>
         * 
         */
                 echo "<table border>";
                 echo "<tr><th>Symbole</th><th>Elément</th></tr>";
                 /**
                  * boucle sur la longeur du tableau
                  * pour recupéré les 2 valeur du tableau faire ($tab as $cle=>$value)
                  */
                 foreach ($tab as $cle=>$value)
                     echo "<tr><td>$cle</td><td>$value</td></tr><br>";
                 
echo "</table>"
        ?>
        </body>
                         
</html>
