<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
        $date = "125/12/45";
        $date1 = "14/09/2016";
        $date2 = "18:06:13";
        function valideDate(&$a){
            //class abrégé (preg_match("#\d{1,2}/\d{1,2}/\{4}#",$a))
        if (preg_match("#^[0-9]{1,2}+/[0-9]{1,2}+/[0-9]{2,4}$#", $a)){
                echo "<div style='color:green;'>"."La chaine $a  est une date valide<br>.";
        }else {
                echo "<div style='color:red;'>"."La chaine $a n'est pas une date valide<br>.";
        }
        return $a;
        };
        valideDate($date);
        valideDate($date1);
        valideDate($date2);
        
        $ch = "Les moteurs de recherche http://www.google.fr et http://www.bing.com sont aujourd'hui les plus utiliser";
        
        $premierEspace = strpos($ch," ");
        $desiemeEspace = strpos($ch, " ", $premierEspace+1);
        $troisiemeEspace = strpos($ch," ",$desiemeEspace+1);
        $quatriemeEspace = strpos($ch, " ",$troisiemeEspace+1);
        $cinquiemeEspace = strpos($ch," ", $quatriemeEspace+1);
        $sisiemeEspace = strpos($ch," ",$cinquiemeEspace+1);
        $setiemeEspace = strpos($ch," ",$sisiemeEspace+1);
          $lien1 = substr($ch, $quatriemeEspace+1, $cinquiemeEspace-$quatriemeEspace);
          $lien2 = substr($ch, $sisiemeEspace+1, $setiemeEspace-$sisiemeEspace);
          echo "lien 1"." "."$lien1<br>";
          echo "lien 2"." "."$lien2<br>";
        if ($lien1 | $lien2){
            echo "Les moteurs de recherche "."<a href='http://google.fr'>$lien1</a>"." et "."<a href='http://bing.fr'>$lien2</a>". "sont aujourd'hui les plus utiliser"."<br><br>";
        }
        
        $ch1 = "Les moteurs de recherche http://www.google.fr et http://www.bing.com sont aujourd'hui les plus utiliser";
        // dans $ch3 on recherche avec une expresion réguliere dans la string quelque chose qui debute par http://
        // apres on transfome la recherche avec une balise <a> et $1 et egale a la chaine selectioné par l'expresion réguliere
        $ch3 = preg_replace("#(http://[a-zA-Z0-9._-]*)#", "<a href='$1'>$1</a>",$ch1);
        echo "AVANT : ".$ch1."<br><br>";
        echo "APRES : ".$ch3."<br><br>";
        
        $hc = "Les Url http://www.mediaforma.com mais aussi https://google.fr et ftp://ftp.cdrom.com peuvent etre transfomés.";
       
       //le ? c'est pour dire que le s dans https et falcutatif
        $hc2 = preg_replace("#((https?|ftp)://[a-zA-Z0-9._-]*)#", "<a href='$1'>$1</a>",$hc);
    
        echo "AVANT : ".$hc."<br><br>";
        echo "APRES : ".$hc2."<br><br>";
       echo "<pre>";
       $tt = "Cette      chaine contient    un    peu   trop d'espace,mais      preg_replace      va siplifier";
       $tt1=preg_replace("# +#", " ",$tt);
        echo "<pre>";
        echo"Avant : ".$tt."<br><br>";      
        echo "Apres : ".$tt1;
        echo "</pre>";
        ?>
    </body>
</html>
