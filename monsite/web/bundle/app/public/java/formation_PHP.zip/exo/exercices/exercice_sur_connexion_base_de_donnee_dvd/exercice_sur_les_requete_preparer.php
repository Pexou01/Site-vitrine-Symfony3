<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
         try {
            $base = new PDO('mysql:host=localhost; dbname=dvd', 'root','');
} catch (exception $e) {
            die('Erreur '.$e->getMessage());
}
$base->exec("SET CHARACTER SET utf8");
$retour=$base->prepare("SELECT nom, prenom FROM membre ");
$retour->execute(array("nom, prenom"));
while ($data = $retour->fetch()){
echo $data["nom"]." ".$data["prenom"]."<br>";
   }
 $base = null;

        ?>
    </body>
</html>
