<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
        
        /**
         *  TUTO SUR phpMyAdmin
         */
        
        /**
         * Les base de données permettent de stocker 
         * des données de tous type de facon organisée et durable contrairement au variable php
         * 
         * dans cette formation on appred à utiliser le SGBD  MySQLi
         * SGBD =  SYSTEM DE JESTION DE BASE DE DONNEESS
         * 
         * Accés objet aux bases de données
         * Suport des instruction Prepared et Multiple
         * Suport des transaction
         * debogage avancé
         * 
         * Les commande SQL seront passées au SGBD via des instruction PHP ou a la main 
         * via la console d'administration web phpmyAdmin ou la console MYSQL
         */
        
        
        
        
        
        
        
        ?>
    </body>
</html>
