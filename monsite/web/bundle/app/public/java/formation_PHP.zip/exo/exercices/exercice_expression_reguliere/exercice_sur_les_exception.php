<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
        /**
         * 
         * test sur les valeur 12 / 0 / 3
         * pour afficher les 3 valeur on met la valeur 12 avant le try et la valeur 3 apres le catch et la 0 dans le try
         *  pour afficher la new exception
         */
      function inverse($nombre){
            if ($nombre == 0)
                throw new Exception("division par zéro");
            else 
                echo "1/$nombre = ".(1/$nombre)."<br>";
                    }
                        echo inverse(12);
                    // les instruction qui ne sont pas sur sont mi dans le try
                    try{
                        // ici la fraction provoque un message d erreur car egale a 0 donc cree une exception
                        echo inverse(0);
                        // quant une exception se produit alor le catch et exécuté puit le programe s'intéron
                    } catch (Exception $e) {
                        echo "Une exception a été générée : ".$e->getMessage()."<br>";
                    }
                    echo inverse(3);
                    
        ?>
    </body>
</html>
