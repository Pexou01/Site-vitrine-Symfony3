<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * encryptage de mot de passe
         * pour crypter une chaine(ici la chaine "monMotDePasse") utilisez la fonction
         * crypt():
         */
        $mdpCrypte = crypt("monMotDePasse");
        /**
         *  maintenent elle peut etre stocker sans sousi dans une base de donée dans un desieme 
         * temp l'orsque l'utilisateur saisi son mot de passe pour accédé a ces donées il
         * faudra la comparé a sa version crypter en utilisen la fonction crypt
         */ 
        // $mdpCrypte représente la saisie enregistré et $mdpSaisiParUtilisateur et le mot de passe 
        // saisie par l'utilisateur et on compare avec la fonction crypte
          if (cript($mdpSaisiParUtilisateur, $mdpCrypte)== $mdpCrypte)
              echo "Le mot de passe est correct.";
          else 
              echo "Le mot de passe est incorrect.";

         
        ?>
    </body>
</html>
