<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * les constante ne peuve etre changer et par convention son ecrite comme cela CONST
         * 
         */
        define("CONST1", "Une chaine constante");
        define("CONST2", 15.4);
        define("CONST_3", true);
        echo CONST1."<br>";
        echo CONST2."<br>";
        echo CONST_3."<br>";
        ?>
    </body>
</html>
