<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
/**
 * toute les expresion a connaitre
 * 
 * Expression    Signification                                                              Exemple
 * 
 *  #         | Caractére de debut et de fin de l'expresion                               | #expression réguliére#    
 *  ^         | Début de la chaine                                                        | ^a sera vrai si la chaine commence pas un a
 *  $         | Fin de la chaine                                                          | t$ sera vrai si la chaine se termine par un t
 *  .         | N'importe quel caractére                                                  | a,b,z,T,1,@,etc
 *  ?         | Répéte 0 ou 1 fois le caractére précédent                                 | xy? Signifie x ou xy
 *  *         | Répéte 0 ou 1 fois ou plusieur fois le caractére précédent                | xy* Signifie x,xy,xyy,xyyy,etc
 *  +         | Répéte 0 ou 1 fois ou plusieur fois le caractére précédent                | xy+ Signifie x,xy,xyy,xyyy,etc
 *  \         | Le caractére déchappement \ autorise l'utilisation d'un caractére special | \. Est équivalent au point décimal                                      
 *  [xyz]     | Un caractére unique de l'expression                                       | [xyr] Signifie x,y ou z
 *  [^xyz]    | Un caractére unique à l'exclusion des caractéres de l'expression          | [^xyz] Signifie un caractére quelconque sauf x,y et z                        
 *  [a-z]     | Un caractére unique compris entre les deux bornes                         | [a-zA-Z] signifie une miniscule ou maj quelconque
 *  exp1|exp2 | Exp1 ou exp2                                                              | PHP4|PHP5 Signifie PHP4 ou PHP5
 *  {min,max} | Répétition du caractére précédent entre min et max fois                   | x{2,3} Signifie xx ou xxx
 *                                                                                        | x{1,} Signifie x,xx,xxx,xxxx,etc
 *                                                                                        | x{,3} Signifie chaine vide,x,xx ou xxx
 */ 
        
        /**
         * Recherche d'une séquence dans une chaine
         * exemple avec une expression reguliere pour test la validité d'une adresse email
         * 
         * #^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$#
         * 
         * # au debut et a la fin delimite l'expréssion réguliere
         * ^[a-z0-9._-]+ signifie que l'adresse mail qui commence par nimporte quel caractaire
         *                lettre minuscule ou chiffre et caractaire special compri entre les crochet
         * @ doit etre suivi d'un arobas
         * [a-z0-9._-]{2,} sequence de 2 lettre min ou chiffre 1 ou plusieur fois
         * \. la chaine et suivid'un point décimale ( \ echape le point )
         * [a-z]{2,4}$ représent une séquence de 2 à 4 caractére a la fin
         */
        
        $email = "pexou.pexou@fai.com";
        // preg_match et une fonction qui teste
        if (preg_match("#^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$#", $email))
                echo "l'Adresse e-mail est valide.";
            else 
                echo "l'Adresse e-mail n'est pas valide.";
              
/**
         * classe abrégée pour expression reguliere
         * 
         * classe abrégée            Correspondance
         * \d                         [0-9]
         * \D                         [^0-9]
         * \w                         [a-zA-Z0-9_]
         * \W                         [^a-zA-Z0-9_]
         * \t                         Tabulation
         * \n                         Saut de ligne
         * \r                         Retour chariot
         * \s                         Espace blanc (correspond à \t\n\r)
         * \S                         Un caractére différent d'un espace
         */
        
        
        
        ?>
    </body>
</html>
