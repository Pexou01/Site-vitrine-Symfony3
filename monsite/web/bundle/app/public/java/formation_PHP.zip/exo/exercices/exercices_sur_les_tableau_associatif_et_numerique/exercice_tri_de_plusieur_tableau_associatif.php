<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * tri de plusieur tableau
         */
        
        
                /**
                 * creation de fonction récursive trier 
                 */
        
        // debut de la fonction trier
                function trier(&$a){
                    // function ksort pour le tri des cle par ordre alphabetique 
                    ksort($a);
            foreach ($a as $cle=>&$valeur){
                        if (is_array($valeur))
                            trier ($valeur);
                    }
                }
                /**
                 * creation de fonction récursive afficher 
                 */
                // debut de la fonction afficher
                function afficher($a){
                //    affiche le decalage a droite avec <blockquote>
                    echo "<blockquote>";
                  // debut de la boucle foreach pour parcourire les tableau
                    foreach ($a as $cle=>$valeur){
                        //affiche la clef des tableau
                        echo $cle." : ";
                        // test si $valeur et un tableau
                        if(is_array($valeur))
                            //appel de la fonction pour afficher pour afficher $valeur
                            afficher ($valeur);
                        // sinon affiche $valeur
                        else 
                        echo $valeur."<br>";
                           
                 }
                 echo "</blockquote>";
                }
                           
        $tab = array("Romain" => array("un"=>"I", "deux"=>"II", "trois"=>"III", "quatre"=>"IV", "cinq"=>"V"),
                     "Arabe"=> array("un"=>"1", "deux"=>"2", "trois"=>"3", "quatre"=>"4", "cinq"=>"5"));
                 trier($tab);
                 afficher($tab);
        
        ?>
    </body>
</html>