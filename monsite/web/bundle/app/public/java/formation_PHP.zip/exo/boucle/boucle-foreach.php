<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * Le foreach et plus adapté pour parcourir un tableau
         * exercice avec le tableau de l'exercice précédent
         */
        echo "<ul>";
        $tab1 = array("Jean", "Pierre", "Paul", "Michel", "Héléne", "Sandrine",
           "Cristel", "Isabelle", "Evariste");
        
       foreach ($tab1 as $value) {
    echo "<li>$value</li>";
          }
echo "</ul>"
?>
    </body>
</html>
