<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
/**
*  syntaxe du WHERE
* 
* Oprérateur   Description                             Exemple 
* +            Egal à                               WHERE prenom='Jean'
* <>           Différent de                         WHERE prenom<>'Pierre'
* >            Supérieur à                          WHERE visite>15
* <            inférieur à                          WHERE total<100
* >=           Supérieur ou égal à                  WHERE visites>=100
* <=           inférieur ou égal à                  WHERE priw<=25
* BETWEEN      A l'intérieur de la plage spécifier  WHERE prix BETWEEN 10 AND 20
* NOT BETWEEN  A l'extérieur de la plage spécifier  WHERE date NOT BETWEEN #10/01/2013# AND #10/06/2013#
* LIKE         Compatible avec le modéle spécifier  WHERE prenom LIKE'P%'   WHERE prenom LIKE '%re%'
* IN           Egal à une des valuers spécifier     WHERE prix in(10,20,30)
* AND          ET logique                           WHERE ville='Paris'ANDprix<1000
* OR           OU logique                           WHERE prix<100 OR visites>1000
* NOT          NON logique                          WHERE prenom NOT IN ('Jean','Pierre')
*/
        ?>
    </body>
</html>
