<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * exemple
         * 
         * ksort(tableau) tri par ordre croissant/alphabétique par clés
         * krsort(tableau) tri par ordre décroissant/ inverse alphabétique par clés
         * asort(tableau) tri croissant/alphabétique par valeur
         * arsort(tableau) tri par ordre décroissant/ inverse alphabétique par valeur
         */
        
       
        ?>
    </body>
</html>
