<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * prinf(format,el1,el2,...,eIn);
         * 
         * format et une chaine qui contien une ou plusieur directive de mise en forme
         * les el sont des élément qui doit etre mise en forme par le directive donne dans le 
         * premier paramétre
         */
        
        /**
         * Directive de mise Effet en forme
         * 
         *  %b   L'argument est traité comme un entier et affiché en binaire
         *  %c   L'argument est traité comme un entier et affiché en tant que code ASCII
         *  %d   L'argument est traité comme un entier et affiché en entier base 10 signé
         *  %e   L'argument est traité comme une notation scientifique
         *  %E   Identique à %e, mais affiche en majuscules
         *  %u   L'argument est traité comme un entier et affiché en entier base 10 non signé
         *  %f   L'argument est traité comme un nombre à virgule flottante (type float)et affiche comme t'el sans tenir compte de la locale
         *  %F   L'argument est traité comme un nombre à virgule flottante (type float)et affiche comme t'el sans tenir compte de la locale
         *  %g   Equivalent à %e et %f
         *  %G   Equivalent à %E et %F
         *  %o   L'argument est traité comme un entier et affiché en octal
         *  %s   L'argument est traité comme un entier et affiché comme une chaine de caractaire
         *  %x   L'argument est traité comme un entier et affiché en hexadécimal, avec les lettres en minuscules
         *  %X   L'argument est traité comme un entier et affiché en hexadécimal, avec les lettres en majuscules
         */
        
        /**
         * exemple de code
         */
        $entier = 125;
        $flottant = 12.45;
        $chaine = "ceci est une chaine";
        
        printf("125 affiché en binaire : %b<br>",$entier);
        printf("125 interprété comme un code ASCII : %c<br>",$entier);
        printf("125 affiché en octal : %o<br>",$entier);
        printf("125 affiché en hexadécimal : %x<br>",$entier);
        printf("12.45 affiché en notation scientifique : %e<br>",$flottant);
        printf("12.45 affiché en nombre à virgule flottante : %f<br>",$flottant);
        ?>
    </body>
</html>
