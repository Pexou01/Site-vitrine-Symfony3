<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * pour intérogé une table dabort on fait
         * 
         * $base = new PDO('mysql:host=localhost; dbname=dvd', 'root','');
         * 
         * on peut utiliser query
         * 
         * $retour = $base->query("requéte sql");
         * 
         * exemple de requéte 
         * 
         * REQUETES                                                  EFFET
         * SELECT*FROM table;                                    affiche tous les enregistrement de la table spécifier
         * SELECT nom FROM table;                                affiche toutes les valeur du champ nom de la table spécifiée
         * SELECT*FROM table WHERE ch=valeur ORDER BY ch2 ASC;   affiche tous les champs de la table spécifiée pour lequel 
         *                                                       le champ ch vaut valeur en classant les reponce par champ ch2 croissant
         * SELECT COUNT(*)FROM table;                            Compte le nombre d'enregistrement de la table spécifier
         * 
         * pour parcourire on utilise la fonction fetch() dans une boucle while
         * 
         * while ($data = $retour->fetch()) {
         * echo $data['champ']."<br>";
         * }
         * 
         * 
         * a la fin il faut detruire l'objet PDO avec
         * 
         * $base = null;
         * 
         * 
         */
        ?>
    </body>
</html>
