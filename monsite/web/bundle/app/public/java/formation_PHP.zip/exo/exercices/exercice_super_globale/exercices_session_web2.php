 <?php
 session_start();
 ?>
<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
         echo $_SESSION["nom"];
             echo $_SESSION["prenom"];
        ?>
    </body>
</html>
