<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
        /**
         * sscanf(chaine,directives,vex1,...); permet d'extraire des données de variable mise en forme
         * Itrim()         Supression des espaces en début de chaine
         * rtrim()         Supression des espaces en fin de chaine
         * str_replace()   Remplace toutes les occurences d'une sous-chaine dans une chaine
         * strlen()        longeur d'une chaine
         * strpos()        recherche de la premiére possition d'une sous-chaine dans une chaine
         * strrchr()       Derniére occurence d'un caractére dans une chaine
         * strrev()        Inverse la chaine spécifiée
         * strrpos         Recherche de la dernier position d'une sous-chaine dans une chaine
         * substr()        extrait une sous-chaine d'une chaine
         * trim()          supprime les espaces en début et en fin de chaine
         * 
         * pour en savoir plus va sur php.net/manual/fr/ref.string.php
         */
        ?>
    </body>
</html>
