<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * class debutant
         */
        
        // require_once =  faire référence au fichier 
        require_once "interfaces.php";
        class debutant{
            public function programme() {
                return
                "<ul><li>Instrution</li><li>Fichiers</li><li>Transmission de données</li></ul>";
            }
            public function pratique() {
                return "Exercices pour appréhender le langage.<br>";
            }
        }
        /**
         * la suite dans le fichier avance.class.php
         */
        ?>
    </body>
</html>
