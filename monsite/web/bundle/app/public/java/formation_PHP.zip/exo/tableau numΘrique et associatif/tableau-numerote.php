<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
       /**
        * 2 type de tableaux
        * numérotés et associatifs
        */
        
        /**
         * exemple tableau numéroté avec la fonction Array();
         */
        $taille = array("trés petit", "petit", "moyen", "grand", "trés grand");
        echo "$taille[3]<br>";
        ?>
    </body>
</html>
