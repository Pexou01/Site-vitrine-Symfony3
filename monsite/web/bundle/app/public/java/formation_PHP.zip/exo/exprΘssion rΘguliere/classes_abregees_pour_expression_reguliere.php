<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * classe abrégée pour expression reguliere
         * 
         * classe abrégée            Correspondance
         * \d                         [0-9]
         * \D                         [^0-9]
         * \w                         [a-zA-Z0-9_]
         * \W                         [^a-zA-Z0-9_]
         * \t                         Tabulation
         * \n                         Saut de ligne
         * \r                         Retour chariot
         * \s                         Espace blanc (correspond à \t\n\r)
         * \S                         Un caractére différent d'un espace
         */
        ?>
    </body>
</html>
