<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * avant tous on fait une instance PDO QUI pointe la base de donnée de la table dvd
         * 
         *   try {
         *   $base = new PDO('mysql:host=localhost; dbname=dvd', 'root','');
         *   } catch (exception $e) {
         *   die('Erreur '.$e->getMessage());
         *   }
         * 
         * apres la conection faite on fait une requette SQL comme sa 
         * 
         *  $base->exec("CREATE TABLE nomTable(champ1 type1(taille1), champs2 type2(taille2)etc..)");
         * nomTable et le nom de la table a crée 
         * le type sont les type des chanps 
         * et les taille son les taille associer au type
         * 
         * pour amélioré les performance des requéte efectuer on peut définire un champ unique incremanté de facon automatique
         * chaque fois qu'un enregistrement  et ajoute dans la table
         * 
         * exemple pour rajouté le champ auto incrémanté on fait 
         * 
         * $base->exe("CREATE TABLE nomTable(id INT NOT NULL AUTO8INCREMENT, ...)");
         * 
         * on peut aussi indexer le champ id en définissant une cléf primaire
         * l'accer au enregistrement sera plus efficasse
         * pour cela on fait 
         * 
         * $base->exec("CREATE TABLE nomTable(id INT NOT NULL AUTO_INCREMENT,PRIMARY KEY(id), ...)");
         */
        ?>
    </body>
</html>
