 <?php
 /**
  * 
  * le modele va récuper les donne et les transmétre au controleur
  */
        function trier($champ){
            $nomchamp=array("OrderId","Customer","employee","OrderDate","nom","prenom");
          }
          try {
            $base = new PDO('mysql:host=localhost; dbname=formation', 'root','');
          } catch (exception $e) {
            die('Erreur '.$e->getMessage());
          }
              $base->exec("SET CHARACTER SET utf8");
              $retour = $base->query("SELECT * FROM orders ORDER BY ".$nomchamp[$champ]);
              $data = $retour->fetchAll();
              return $data;
        ?>
    

