<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // example de déclaration de variable 
        $monTexte = "Ce texte est mémorisé dans la variable \"monTexte\"";
        $valeur_flottante = 12.5;
        $monBooleen = true;
        $monTableau = array('un', 'deux', 'trois', 'quatre', 'cinq');
        class maClasse{
            
        }
        $monObjet = new maClasse();
        
        // affiché le contenue des variable
        echo $monTexte."<br>";
        echo $valeur_flottante."<br>";
          echo $monBooleen."<br>";
                     
        // pour afficher le type 
        echo gettype($monTexte)."<br>";
        echo gettype($valeur_flottante)."<br>";
        echo gettype($monBooleen)."<br>";
        echo gettype($monTableau)."<br>";
        echo gettype($monObjet);
        
        ?>
    </body>
</html>
