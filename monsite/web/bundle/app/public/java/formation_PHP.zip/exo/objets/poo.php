<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * Les classes définissent des structures composées de variable et de fonction.
         * 
         * Les variable d'une classe sont appelées propiétés.
         * 
         * Les fonctions de la classe sont appelées methodes.
         * 
         * Les instances, c'est à dire less utilisations d'un type de classe, sont appelées des objets.
         * 
         * Les variables et les fonctions d'une classe sont zppelés composants ou membres de la classe.
         */
        /**
         * exemple analogique
         * 
         * LA CLASS
         * imagine une class comme une usine de voiture 
         * les instance la classe sont des voiture (les object)
         * colleur silindré etc son des caractéristique des propriété prope a chaque voiture
         * suivant le type de voiture a construire il faudra plusieur methode
         * 
         */
        ?>
    </body>
</html>
