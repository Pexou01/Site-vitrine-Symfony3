<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * quelque  fonction sur les date et heure
         * pour plus info va sur www.php.net/manual/fr/function.date.php
         */
        // fonction date avec comme parametre d/m/Y LE Y majuscule dit que je veu l'année compléte
        $date = date("d/m/Y H:i:s");
        echo "$date";
        ?>
    </body>
</html>
