<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // include_once fait référence au fichier qui contien la class 
        include_once("exercice_sur_les_class_et_creation_objet.php");
        // creation de l'objet sur la class chaineplus avec comme parametre "Programmation orientée objet en PHP"
        $objet = new chaineplus("Programmation orientée objet en PHP");
       //affichage du parametre gras 
       echo"Gras : ".$objet->gras();
        //affichage du parametre italique
       echo"Italique : ".$objet->italique();
        //affichage du parametre souligne 
       echo"Souligner : ".$objet->souligne();
        //affichage du parametre majuscule 
       echo"Majuscule : ".$objet->majuscule();
        ?>
    </body>
</html>
