<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <!-- formulaire speciale pour la transmission de donée  'est enctype qui le permet inisialiser avec  multipart/form-data-->
        <form action="ouverture-fichier.php" method="post" enctype="multipart/form-data">
            Choisissez un fichier texte (extension .txt)<br>
            <!-- type="file permet de selectioné un fichier -->
            <input type='file' name="fichierTexte"><br>
            <input type="submit" value="Envoyer">
                        </form>
        <?php
        
        ?>
    </body>
</html>
