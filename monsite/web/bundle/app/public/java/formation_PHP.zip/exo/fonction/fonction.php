<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * pour définir une fonction
         * 
         * function nom(param1,param2,etc) mes 1 parametre sufit et return valeur et retourné si elle et spécifier
         * exemple
         * 
         * function affiche($a,$b){
         * Une ou plusieurs instructions
         * return $valeur;
         * }
         */
        //création de la fonction cube
        function cube($nombre){
            return $nombre*$nombre*$nombre;
        }
        // appel de la fonction cube avec la valeur 5
        echo cube(5)
        ?>
    </body>
</html>
