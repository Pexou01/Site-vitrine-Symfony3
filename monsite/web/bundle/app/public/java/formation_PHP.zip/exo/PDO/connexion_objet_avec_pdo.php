<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
/**
*  PDO  = PHP DATA OBJETS 
* 
* La connexion avec la base de données se fait en créant une instance de la class PDO:
* 
* $base = new PDO('mysql:host=nom serveur; dbname=nom base de donnée','nom utilisateur', 'mot de passe');
 * nom serveur et le nom serveur base de donnée
 * nom base et le nom de la base de donnée
 * nom utilisateur et le nom utilisateur qui faut utiliser pour se conecté  a la base de données
 * mot de pass et le mot de pass associer au nom utilisateur choisi
*/
     //   $base = new PDO('mysql:host=localhost; dbname=formation', 'root','');
       
        /**
         * pour testé la connection on utilise un try catch
         * teste le try catch si un message apparai ces que un probléme sur la connection
         * a la base de donée
         */
        
        try {
            $base = new PDO('mysql:host=localhost; dbname=formation', 'root','');
} catch (exception $e) {
            die('Erreur '.$e->getMessage());
}
/**
 * avant tous il faut dire le type dencodage en l'occurence utf8 avec la methode exec
 */
$base->exec("SET CHARACTER SET utf8");
/**
 * pour lire le contenue d'une table on fait une requete sql
 * cette requete sera passé à l'objet PDO de la base avec la methode query et
 * requete entre guilemet ces la requéte à executé 
 * 
 * $retour = $base->query('requete');
 */

/**
 * exemple si on veu toute les donnée de la table utilisateur de la base de donnée formation 
 */
$retour = $base->query('SELECT * FROM utilisateurs');

/**
 * il ne reste plus qua traité les donnée reçu avec une boucle while 
 */
while ($base = $retour->fetch()){
    
    echo 'Bonjour '.$data['nom'].' '.$data['prenom'].'. Votre login : '.$data['login'].'<br>'
            .'. Votre mot de passe'.$data['password'].'<br>'
            .': Vous voila connecté avec cette email : '.$data['email'].'<br>'
            .'. Votre numéro client : '.$data['index'].'<br>';
    $base = null;
}
/**
 * pour metre fin a la connexion on fait
 * $base = null;
 */ 
 
        ?>
    </body>
</html>
