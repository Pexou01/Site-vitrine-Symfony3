<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * élément choisi par l'utilisateur et afficher
         * 
         * 
         * Elément du tableau                       signification
         * $_FILES["fichierTexte"]["name"]         le nom original u fichier tel qu'il a été défini sur la machine
         * $_FILES["fichierTexte"]["type"]         le type MIME du fichier si le navigateur a fourni cette information
         * $_FILES["fichierTexte"]["size"]         la taille en octect du fichier télécharger
         * $_FILES["fichierTexte"]["tmp_name"]     le nom temporaire du fichier qui sera chargé sur la machine serveur
         * $_FILES["fichierTexte"]["error"]        le code erreur associé au téléchargement de fichier
         * 
         * move_uploaded_file(temp,non);
         * temp = et le nom du fichier a télécharger 
         * non = et la cible ou va etre télécharger le fichier
         */  
        /**
         * code qui permet de sauvegarder le fichier envoyer
         */
        // si le fichier texte existe dans la super globale $_FILES et que aucune erreur ne c'est produit
        // alor il recupére les donné $tmp_name et $name
        if (isset($_FILES["fichierTexte"]) AND $_FILES["fichierTexte"]["error"] == 0){
            // si le fichier fait moi de 10000 octect alor il poursuit sinon il affiche l'erreur du dernier echo
            if (($_FILES["fichierTexte"]["size"]<10000) AND ($_FILES["fichierTexte"]["type"] == "text/plain")){
                // il récupére en lisent les celule tmp_name et name du tableau $_FILES DE FICHIER TEXTE ET SON STOCKE DANS
                // $name et $tmp_name
                                $tmp_name = $_FILES["fichierTexte"]["tmp_name"];
                $name = $_FILES["fichierTexte"]["name"];
               // pour trensféré les fichier du client au serveur on utilisant la fonction move_uploaded_file($filename, $destination)
                move_uploaded_file($tmp_name, $name);
                echo "FICHIER TRANSMIE";
            }
 else 
                echo "Le fichier spécifié n'est pas un fichier texte ou sa taille dépasse les 10000 octects<br>'" ;
        }
        else 
            echo "Une érreur s'est produite pendant le téléchargement'";
            

        ?>
    </body>
</html>
