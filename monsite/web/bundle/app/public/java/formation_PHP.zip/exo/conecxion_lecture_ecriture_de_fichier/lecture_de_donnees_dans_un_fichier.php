<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * pour lire caractaire par caractaire on fait
         * $car = fgetc("$handle");
         * 
         * pour lire ligne par ligne on fait 
         * $ligne = fgets("$handle");
         * 
         * si le fichier contient plusieur caractaire  et ou ligne on doit le parcourire avec une boucle
         * 
         * POUR TESTER MA FIN DE FICHIER ON FAIT
         * feof("$handle") elle retourne false si la fin du fichier n'est pas ateinte et 
         * true dans le cas contraire.
         */
        ?>
    </body>
</html>
