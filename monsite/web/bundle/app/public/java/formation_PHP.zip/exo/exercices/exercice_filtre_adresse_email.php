<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * création d'une fonction filtre
         */
        function filtreEmail($data){
            // la fonction strpos recherche si la data comporte un @ 
            $arobas= strpos($data, "@");
            //la fonction strrpos recherche  le dernier point de la data
            $dernierPoint = strrpos($data, ".");
            //si ya un @  
            if (($arobas!=false)&&
                    // si ya un .
                    ($dernierPoint!=false)&&
                    // si le point et au moin à 3 caractaire du @
                    ($dernierPoint - $arobas >=3)){
                // si email et corecte alor il s'affiche
                return true;
                    }else{
                // sinon n'affiche pas        
                return false;
        }
        }
        $adresses = array("nom.com", "nom@fai.com", "nom@fai", "mon.pre@fai.com", "nom@fai.fr", "non@t.fr");
        // le tableau et filtré avec array_filter
        $adresseValides = array_filter($adresses, "filtreEmail");
        // ici on fait une boucle du tableau et on affiche que les adresse valide du tableau 
        foreach ($adresseValides as $value){
            echo $value."<br>";
        }
        ?>
    </body>
</html>
