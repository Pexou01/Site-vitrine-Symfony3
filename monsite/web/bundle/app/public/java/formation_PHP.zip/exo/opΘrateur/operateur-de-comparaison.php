<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         *  == test d'égalité de valeurs
         *  ===  test d'égalité de valeurs ou de types de données
         *  != test de différence entre deux valeurs
         *  !== tes de différence entre deux valeur ou deux types de données
         *  < test si une valeur est inférieure à une autre
         *  > test si une valeur est supérieur à une autre
         *  <= test si une valeur est inférieure ou égale à une autre valeur
         *  >= test si une valeur est supérieur  ou égale à une autre valeur
         */
        
        ?>
    </body>
</html>
