<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
       /** pour les fonction mathématique
        * elle sont disponible sur www.php.net/manual/fr/ref.math.php
        * 
        * pour les fonction sur les string
        * elle sont sur www.php.net/manual/fr/ref.strings.php
        */
        
        /**
         * exemple de fonction mathématique dispo sur le site
         */ 
         function decimalToFraction($decimal,$count,$result) { 
         $a = (1/$decimal); 
         $b = ( $a - floor($a)  ); 
         $count++; 
         if ($b > .01 && $count <= 5) decimalToFraction($b,$count,&$result); 
         $result[$count] = floor($a); 
}
        /**
         * exemple de fonction pour les strings dispo sur le site
         */ 
        function get_string_between($string, $start, $end){
        $string = " ".$string;
        $ini = strpos($string,$start);
        if ($ini == 0) return "";
        $ini += strlen($start);     
        $len = strpos($string,$end,$ini) - $ini;
        return substr($string,$ini,$len);
}

        
        ?>
    </body>
</html>
