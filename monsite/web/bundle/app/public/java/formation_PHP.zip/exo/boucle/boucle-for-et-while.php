<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * boucle for
         */
        
        for ($i = 1; $i<10; $i++){
            // ici echo est répété 9 fois
            echo "&dollar;i vaut $i<br>";
        }
        /**
         *  boucle while
         * ici $i est égale à zero aprés la boucle while va se lancer jusqua
         * que $i fasse 10 donc ici 10 fois 
         */
        $i=0;
        //tanque $i et inférieur a 10 alor tu fait sa 
        while ($i<10) {
            // on incrémente i jusqua que $i vaut 10
            $i++;
            //affiche 
            echo "&dollar;i vaut $i<br>";
            // une fois $i égale a 10 alor la bouclz s'arréte
        }
        ?>
    </body>
</html>
