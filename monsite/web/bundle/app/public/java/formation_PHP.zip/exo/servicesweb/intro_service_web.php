<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * le language PHP permet de crée des service web (programme libre d'accée qui s'execute sur un serveur web et qui permet  
         * d'échanger des données entre le client et le serveur.
         * pour étre en mesure de crée et d'utiliser les service web sur votre serveur locale xampp serveur on doit activé l'extention soap
         * pour lactivé tu va sur le php.ini de xampp et tu cherche la ligne ;extension=php_soap.dll pour activé enléve juste la majuscule
         */
        ?>
    </body>
</html>
