<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
 /**
  * lorsque une variable est pasée a une fonction 
  * elle peut etre utilisé dans la fonction mais sa valeur n'est pas 
  * altéré en dehort de la fonction
  */
        
 /**
  * si on veut que lea fonction puisse modifier la variable exterieur
  * on doi faire un passage de parametre par référence en ajoutent un &
  * devant le parametre dans les argument dde la fonction
  */       
        /**
         *exemple
         * function passageParReference(&$variable) {
         * }
         */
        
        function ajouterRef(&$a){
            $a = $a . "Texte de fin";
        }
        function ajouter($a){
            $a = $a . "Texte de fin";
        }
        
        $chaine = "Texte du debut.";
        
        ajouter($chaine);
        // la variable $chaine n'est pas altéré par la fonction ajouté
        echo $chaine."<br>";
        
        ajouterRef($chaine);
        // la variable et altéré car elle et passer par référence dans la fonction 
        // ajouterRef car dans les parametre y a (& $nom de variable) le & et important car passe par référence
        echo $chaine."<br>";
        ?>
    </body>
</html>
