<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * elle permet de recevoir plusieur résultat d'un champ
         * exemple pour compté le nombre de commande par paye on utilise
         * 
         * SELECT membre,
         * COUNT(nom) FROM 
         * orders GROUP BY 
         * nom;
         */
        ?>
    </body>
</html>
