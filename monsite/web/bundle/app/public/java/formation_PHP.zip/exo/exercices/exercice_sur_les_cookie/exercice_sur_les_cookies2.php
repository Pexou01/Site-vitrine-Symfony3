 <?php
 session_start();
 ?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        echo $_COOKIE["nom"]."<br>";
             echo $_COOKIE["prenom"]."<br>";
             var_dump($_COOKIE);
             
        ?>
    </body>
</html>
