<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
         <style>
            #image{
                width: 30px;
                height: 30px;
            }
        </style>
    </head>
    <body>
        <!-- name représente le nom du formulaire action représente le fichier utilisé pour le formulaire  et method représente la façon ou va etre traité-->
<form name="nom" action="traitement.php" method="post">
</form>

<!--fieldset pérmet de reunire un groupe option qui permetera de rassemblé plusieur chan-->
<fieldset>contenu</fieldset>

<!-- permet de metre une legende d'une donée dans le fieldset-->
<legend>texte</legend>

<!--simple légende texte-->
<label>texte</label>

<!--input représente une zone de text le type et donc du text son name et nom son id et identifiant et la valeur affiché et valeur-->
<input type="text"name="nom" id="identifiant" value="valeur"><br><br>

<!-- input suiven représente un bouton de type button avec un name qui et nom son id et identifiant et la valeur afficher dans le bouton et valider-->
<input type="button" name="nom" id="identifiant" value="valider"><br><br>

<!-- imput suivent représente un bouton contenent une image src c'est le lien du fichier image et id ces image-->
<input type="image" src="pictures/super.png" id="image"><br><br>

<!--input suivent représente la saisi d'un password avec le name nom son id password et la valeur par default-->
<input type="password" name="nom" id="password" value="valeur par default"><br><br>

<!--input suivent représente une case a coché  name = nom id = checkbox et sa valeur et la valeur par default-->
<input type="checkbox" name="nom" id="checkbox" value="valeur par default"><br><br>

<!--input suivent représente un bouton radio toujour avec les atribu name id et value-->
<input type="radio" name="nom" id="identifiant" value="valeur"><br><br>

<!--input suivent représente un chand cachée malgré quil ne sois pas afficher il et envoyer au formulaire quand utilisateur va cliqué sur submit -->
<input type="hidden" name="nom" id="identtifiant" value="valeur"><br><br>

<!--input suivent et le bouton de validation et envoie formulaire toujour avec son name nom son id identifiant et sa valeur afficher dans le bouton-->
<input type="submit" name="nom" id="identifiant" value="texte afficher dans le bouton"><br><br>

<!--input suivent représent un bouton reste du formulaire avec son name nom sont id identifiant et sa valeur affiché -->
<input type="reset" name="nom" id="identifiant" value="texte affiché dans le bouton"><br><br>

<!--input suivent représente un chan etudié pour les email avec son name  nom son id identifiant -->
<input type="email" name="nom" id="identifiant" ><br><br>

<!--input suivent représente un chan expres pour les url avec sont name non et sont id identifiant-->
<input type="url" name="nom" id="identifiant" ><br><br>

<!-- input suivent représente un fichier local permet a lutilisateur de selectioné un ficher et a l'envoyer au formulaire-->
<input type="file" name="nom" id="identifiant"><br><br>

<!-- textarea represent une zone de text les atribu cols represente le nombre de colonne et rows le nombre de ligne-->
<textarea cols="nombre colonnes" rows="nombre de ligne" id="identifiant">TEXTE PAR DEFAULT</textarea><br>

<!--select représente un formulaire de selection avec plusieur option possible-->
<select name="nom" id="identifiant">
<option >valeur1</option>
<option >valeur2</option>
</select>
        <?php
        // put your code here
        ?>
    </body>
</html>
