<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
       try {
            $base = new PDO('mysql:host=localhost; dbname=basephp', 'root','');
           } catch (exception $i) {
           die('Erreur '.$i->getMessage());
           }
           $base->exec("UPDATE membrephp SET nom=UCASE(nom) WHERE compteur_visite>35");
         
           $retour = $base->query('SELECT * FROM `membrephp`');
while ($data = $retour->fetch()){
echo "<table border : solid><th>Bonjour Mr ".$data['nom'].' '.$data['prenom']."</th><br>
        </table>";
       
   }
           $base = null;
        ?>
    </body>
</html>
