<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
 /**
 * il existe 2 tpe de fonction SQL
 * 
 * LES FONCTION SCALAIRE: UPPER(), LOWER(), LENGTH(), ROUND() elle saplique a toute les valeur passer
 * 
 * LES FONCTION DAGREGAT : AVG(), SUM(), MAX(), MIN(), COUNT() elle éféctue des calcule sur une table et retourne le résultat
*/
        
        /**
         * exemple avec la fonction minuscule majuscule sur la table membre de la bd dvd 
         */
        
        try {
            $base = new PDO('mysql:host=localhost; dbname=dvd', 'root','');
} catch (exception $e) {
            die('Erreur '.$e->getMessage());
}
$base->exec("SET CHARACTER SET utf8");
$retour = $base->query('SELECT LOWER nom
         FROM `membre`');
while ($data = $retour->fetch()){
echo 'Bonjour Mr '.$data['nom']."<br>";
        
   }
 $base = null;
        ?>
    </body>
</html>
