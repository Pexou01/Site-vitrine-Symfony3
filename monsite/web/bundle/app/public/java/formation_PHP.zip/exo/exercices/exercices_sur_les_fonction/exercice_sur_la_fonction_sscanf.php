<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * extraction des donnée de la chaine
         */
        
        $dateEtHeure = "15 juin 2014 20:12:15";
        sscanf($dateEtHeure, "%d %s %d %d:%d:%d", $jour, $mois, $annee, $heure, $minute, $seconde);
        echo"Jour : ".$jour.", Mois : ".$mois." , Année : ".$annee." , Heure : ".$heure.":".$minute.":".$seconde;
        ?>
    </body>
</html>
