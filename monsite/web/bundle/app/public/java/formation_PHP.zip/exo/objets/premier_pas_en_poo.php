<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * définition d'une class
         * pour définire une classe il sufi de déclaré class avec le nom de la class
         * 
         *     class chainePlus {
         *       une ou plusieur instruction
         *      }
         * pour définire les propriété de la class on utilise les mot PUBLIC , PRIVATE OU PROTECTED
         * 
         * PUBLIC = accecible dans la class dans les dérivé et les objet
         * PRIVATE = si elle n'est utilisé que dans la class 
         * PROTECTED = accecible dans la class dans les  class dérivé 
         * 
         * exemple 
         * 
         * private $nomProp,
         * $nomProp et le nom d'une propriété
         * 
         * pour définire des fonctoin membre on fait
         * 
         *   public function nom(){
         *    une ou plusieurs instructions
         *    $this->nomProp premet d'accéder à la propriété nomProp
         *   } 
         */     
        ?>
    </body>
</html>
