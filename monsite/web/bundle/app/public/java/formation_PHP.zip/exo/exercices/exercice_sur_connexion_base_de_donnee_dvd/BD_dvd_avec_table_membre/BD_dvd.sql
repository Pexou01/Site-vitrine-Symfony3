﻿create database dvd;

USE dvd;


SET FOREIGN_KEY_CHECKS = 0;


create table films(id_code int(11) auto_increment primary key, Film_Titre varchar(50),Prix char(5),Date_De_Sortie char(15),Acheteur varchar(40));

insert into films 
 values
(1,'Resident evil', 19.90, '21/06/2011','Cedric'),
 
(2,'Le raid', 17.45, '11/02/2007','Frédéric'),
 
(3,'La reine des neige', 16.50, '18/11/2012','Lysa'),
 
(4,'Toy s Story', 11.61, '30/01/2008','Jennifer'),
 
(5,'La Chambre 1409', 1.25, '06/08/2009','Cleya'),
 
(6,'Freddy 2', 9.47, '19/07/2015','Zoe'),
 
(7,'Avenger', 29.21, '14/09/2017','Morgane'),
 
(8,'Hulk', 10.11, '09/03/2010','Enzo'),
 
(9,'Le Cercle', 14.99,'28/05/2003','Shaina'),
 
(10,'La Chute De La Maison Blanche', 7.94, '24/09/2006','Mateo');


create table membre(id_code int(11) auto_increment primary key, nom varchar(30),prenom varchar(15),adresse varchar(80),cp char(5),date_anniversaire char(15));

insert into membre 
values
(1,'Dupont','Frédéric', '21 rue fefe',95300,'06/08/1986'),

(2,'Durant','Cedric', '15 rue fefe',95520,'06/06/2009'),

(3,'Dupont','Lysa', '21 rue fefe',95300,'31/12/2009'),

(4,'Dupont','Cleya', '21 rue fefe',95300,'30/06/2007'),

(5,'Dupont','Morgane', '21 rue fefe',95300,'29/05/2012'),

(6,'Dupont','Zoe', '21 rue fefe',95300,'09/11/2015'),

(7,'Dupont','Jennifer', '21 rue fefe',95300,'26/03/1986'),

(8,'Leblanc','Mateo', '14 rue fefe',95810,'21/09/2014'),

(9,'Machi','Enzo', '61 rue fefe',95300,'14/10/2004'),

(10,'Do','Shaina', '03 rue fefe',95300,'16/04/2012');

create table villes(id_code char(50),nom_ville varchar(30),cp int(5) auto_increment primary key);

insert into villes 
values
(1,'Pontoise','95300'),

(2,'Osny',95520),

(3,'Cergy',95800),

(4,'Paris',75011),

(5,'Lyon',69210);


create table telephone(id_code int(11) auto_increment primary key, n_telephone char(14),nom char(30));

insert into telephone 
values
(1,'01.34.35.11.21','Durant'),

(2,'01.39.41.14.12','Dupont'),

(3,'02.24.11.55.66','Leblanc'),

(4,'01.32.15.84.96','Do'),

(5,'01.55.68.74.11','Machy');