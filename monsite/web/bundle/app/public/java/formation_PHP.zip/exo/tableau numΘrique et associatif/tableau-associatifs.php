<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
       /**
        * 2 type de tableaux
        * numérotés et associatifs
        */
        
        /**
         * exemple tableau associatif avec la fonction Array();
         * sa marche sous forme de clef = une valeur séparé par des virgule
         */
        
        $calories = array("Pain au chocolat" => "410",
                          "Miel" => "304",
                          "Réglisse" => "377",
                          "Sorbet" => "90",
                          "Sucre" => "395",
                          "Cookies" => "464");
        // pour afficher une valleur d'un élément on fait comme sa
        echo $calories["Sorbet"]."<br>";
        // pour parcourir tous les élément d'un tableau avec la boucle FOREACH
        foreach($calories as $cle => $valeur)
            echo $cle." = ".$valeur.", "."<br>";
        
        ?>
    </body>
</html>
