<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
     //création de la fonction affiche
                       function affiche($a){
                           //<blockquote> indique que le texte contenu dans l'élément pour metre l'afficharge a droite' 
                       echo "<blockquote>";
                       //parcourt du tableau avec une boucle foreach
                       foreach($a as $cle=>$valeur){
                           // la cle et afficher avec un espace et un :
                           echo $cle." : ";
                           // si la valeur et un tableau alor je la transmé a la fonction affiche et sera décalé grace a <blockquote>
                           if(is_array($valeur))
                               affiche ($valeur);
                           // si la valeur n'est pas un tableau alor elle affiche la valeur
                           else   
                           echo $valeur."<br>";
                       }
                       // apres le foreach on affiche la fin de l'indentaion a droite avec la balise </blockquote>
                       echo "</blockquote>";
                       }
   $tableau2 = array("Romain" => array("un"=>"I", "deux"=>"II", "trois"=>"III", "quatre"=>"IV"),
                           "Arabe" => array("un"=>"1", "deux"=>"2", "trois"=>"3", "quatre"=>"4"));  
   // appel de la fonction recursive qui sapel elle meme
                       affiche($tableau2);       
          
        ?>
    </body>
</html>
