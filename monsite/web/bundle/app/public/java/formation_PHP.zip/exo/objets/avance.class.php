<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // require_once = faire référence au fichier 
        require_once "interfaces.php";
        class avance{
            public function programme() {
                return
                "<ul><li>SuperGlobales</li><li>POO</li><li>BD</li></ul>";
            }
            public function pratique() {
                return "Nombreux exercices de tous niveaux.<br>";
                
            }
        }
        /**
         * suite dans formation.php
         */
        ?>
    </body>
</html>
