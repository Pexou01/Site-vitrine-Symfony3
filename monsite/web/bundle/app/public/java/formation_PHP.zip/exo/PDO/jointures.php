<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /**
         * Les bases de données relationel comme mysql permet incéré plusieur table dans une base de données et de définire 
         * des relation entre elle
         * 
         * on va travailé sur plusieur table simultanément  en PHP grace au jointure EN RELIENT LES TABLE PAR l'intermédiere d'un champ
         * commin
         * la jointure simple
         * A titre d'éxemple nous allo, relier les table membre et films de la base de données dvd
         * elle seront relier avec leur champ id a chacune
         * en utilisent une requete sql aproprié il sera possible dextraire des données de ces deux table en les relien avec leur id
         * 
         * plusieur syntaxe sont possible 
         * 
         * Pour selectioné tous les champs des ables membre et films pour lequels le champ id et identique dans les deux tables:
         * 
         * SELECT * FROM membre, films WHERE membre.id_code=films.id_code;
         * 
         * Instruction identique à la précédente mais on utilise des alias sur les tables pour simplifier l'écriture
         * 
         * SELECT * FROM membre as o, films as d WHERE o.id_code=d.id_code;
         * 
         * 
         * Sélection des champs id_code de la table membre et films pour lequels le champ id_code est identique dans les deux table
         * 
         * SELECT membre.nom,
         *  films.Film_Titre 
         * FROM membre, films 
         * WHERE membre.id_code=films.id_code
         * 
         * se code affiche la colone nom de la table membre et Film_Titre de la table films
         */
           
        ?>
    </body>
</html>
