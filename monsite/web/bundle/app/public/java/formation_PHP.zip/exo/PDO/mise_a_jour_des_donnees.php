<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
       /**
        *  pour metre a jour des donée on fait
        * 
        * UPDATE table SET champ1=valeur1, champ2=valeur2, champ3=valeur3 WHERE champN=valeurN;
        * 
        * table et le nom de la table conserné
        * champ1 à champ3 son les champ a modifier
        * valeur1 valeur2 valeur3 son les valeur a afecté à champ1 champ2 champ3
        * champN et valeurN définice la condition de selection le ou les enregistrement a modifier
        */
        ?>
    </body>
</html>
